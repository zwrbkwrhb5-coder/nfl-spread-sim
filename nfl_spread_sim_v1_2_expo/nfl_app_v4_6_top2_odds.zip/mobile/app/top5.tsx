import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import BottomNav from "../components/BottomNav";
import BrandHeader from "../components/BrandHeader";
import {
  kickoffText,
  lineText,
  oddsText,
  pct,
  signed,
  teamLogo,
  upcomingQualifiedPicks,
} from "../data";
import { C } from "../theme";

export default function Picks() {
  const picks = upcomingQualifiedPicks();

  return (
    <SafeAreaView style={s.page}>
      <FlatList
        data={picks}
        keyExtractor={(x) => `${x.game.id}-${x.pick.market}`}
        contentContainerStyle={s.content}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListHeaderComponent={
          <>
            <BrandHeader />
            <Text style={s.title}>Best Bets</Text>
            <Text style={s.sub}>Only upcoming qualifying model plays</Text>
          </>
        }
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={s.emptyTitle}>No upcoming qualifiers</Text>
            <Text style={s.emptyText}>
              The model will not lower the edge threshold just to create a pick.
            </Text>
          </View>
        }
        renderItem={({ item, index }) => (
          <View style={[s.card, index === 0 && s.heroCard]}>
            <View style={s.rank}>
              <Text style={[s.rankText, index === 0 && { color: "#17120A" }]}>
                {index === 0 ? "♛  #1 PICK" : `#${index + 1}`}
              </Text>
            </View>

            <View style={s.pickHeader}>
              <Image source={{ uri: teamLogo(item.pick.pick) }} style={s.logo} />
              <View style={{ flex: 1 }}>
                <Text style={s.pickTitle}>
                  {lineText(item.pick.market, item.pick.pick, item.pick.line)}
                </Text>
                <Text style={s.vs}>
                  {item.game.away} @ {item.game.home} • {kickoffText(item.game)}
                </Text>
              </View>
            </View>

            <View style={s.metrics}>
              <View style={s.metric}>
                <Text style={s.metricLabel}>EDGE</Text>
                <Text style={[s.metricValue, { color: C.gold }]}>
                  {signed((item.pick.edge ?? 0) * 100, 2)}%
                </Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>PRICE</Text>
                <Text style={s.metricValue}>{oddsText(item.pick.odds)}</Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>MODEL</Text>
                <Text style={s.metricValue}>{pct(item.pick.selectedProbability)}</Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>BREAK EVEN</Text>
                <Text style={s.metricValue}>{pct(item.pick.breakEven)}</Text>
              </View>
            </View>

            <View style={s.topTwoWrap}>
              <Text style={s.topTwoTitle}>TOP 2 AVAILABLE OPTIONS</Text>

              {(item.pick.oddsBoard.length
                ? item.pick.oddsBoard.slice(0, 2)
                : [{
                    line: item.pick.line,
                    odds: item.pick.odds,
                    book: item.pick.book,
                    edge: item.pick.edge,
                    selected: true,
                  }]
              ).map((q, qi) => (
                <View
                  key={`${q.book}-${q.line}-${q.odds}-${qi}`}
                  style={[s.optionCard, qi === 0 && s.optionCardBest]}
                >
                  <View style={s.optionRank}>
                    <Text style={[s.optionRankText, qi === 0 && { color: "#17120A" }]}>
                      {qi === 0 ? "★ #1 BEST" : "#2 NEXT BEST"}
                    </Text>
                  </View>

                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={s.optionBook}>{q.book}</Text>
                    <Text style={s.optionLine}>
                      {lineText(item.pick.market, item.pick.pick, q.line)}
                    </Text>
                  </View>

                  <View style={s.optionRight}>
                    <Text style={[s.optionOdds, qi === 0 && { color: C.gold }]}>
                      {oddsText(q.odds)}
                    </Text>
                    <Text style={[s.optionEdge, qi === 0 && { color: C.green }]}>
                      {q.edge == null ? "—" : `${signed(q.edge * 100, 2)}% edge`}
                    </Text>
                  </View>
                </View>
              ))}

              <Text style={s.shopHelp}>
                Ranked by model edge, so line and juice are evaluated together.
              </Text>
            </View>
          </View>
        )}
      />

      <BottomNav active="picks" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 100 },
  title: { color: C.text, fontSize: 36, fontWeight: "900", marginTop: 21 },
  sub: { color: C.muted, fontSize: 14, marginTop: 1, marginBottom: 18 },

  card: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 15,
  },
  heroCard: {
    borderColor: C.gold,
    shadowColor: C.gold,
    shadowOpacity: 0.22,
    shadowRadius: 9,
  },
  rank: {
    alignSelf: "flex-start",
    backgroundColor: C.gold,
    borderRadius: 99,
    paddingHorizontal: 11,
    paddingVertical: 6,
    marginBottom: 12,
  },
  rankText: { color: "#17120A", fontSize: 9, fontWeight: "900" },
  pickHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  logo: { width: 56, height: 56, resizeMode: "contain" },
  pickTitle: { color: C.text, fontSize: 23, fontWeight: "900" },
  vs: { color: C.muted, fontSize: 10, marginTop: 3 },

  metrics: {
    flexDirection: "row",
    backgroundColor: C.panel2,
    borderRadius: 13,
    marginTop: 14,
    padding: 12,
  },
  metric: { flex: 1 },
  metricLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  metricValue: { color: C.text, fontSize: 13, fontWeight: "900", marginTop: 3 },
  topTwoWrap: {
    backgroundColor: C.panel2,
    borderRadius: 13,
    padding: 10,
    marginTop: 12,
  },
  topTwoTitle: {
    color: C.muted,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1,
    marginBottom: 7,
  },
  optionCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    backgroundColor: "#0D1115",
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 11,
    padding: 10,
    marginBottom: 7,
  },
  optionCardBest: {
    backgroundColor: "#171409",
    borderColor: C.gold,
  },
  optionRank: {
    minWidth: 68,
    borderRadius: 99,
    paddingHorizontal: 7,
    paddingVertical: 5,
    backgroundColor: C.gold,
    alignItems: "center",
  },
  optionRankText: {
    color: "#17120A",
    fontSize: 7,
    fontWeight: "900",
  },
  optionBook: {
    color: C.text,
    fontSize: 11,
    fontWeight: "900",
  },
  optionLine: {
    color: C.muted,
    fontSize: 9,
    marginTop: 2,
  },
  optionRight: {
    alignItems: "flex-end",
    minWidth: 58,
  },
  optionOdds: {
    color: C.text,
    fontSize: 14,
    fontWeight: "900",
  },
  optionEdge: {
    color: C.muted,
    fontSize: 8,
    fontWeight: "900",
    marginTop: 2,
  },
  shopHelp: { color: C.dim, fontSize: 8, lineHeight: 13, marginTop: 2 },

  empty: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 20,
  },
  emptyTitle: { color: C.text, fontSize: 18, fontWeight: "900" },
  emptyText: { color: C.muted, lineHeight: 18, marginTop: 6 },
});
