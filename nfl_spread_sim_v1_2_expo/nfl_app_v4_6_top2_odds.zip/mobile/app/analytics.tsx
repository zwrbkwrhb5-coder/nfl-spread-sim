import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import BottomNav from "../components/BottomNav";
import BrandHeader from "../components/BrandHeader";
import { APP_DATA, signed } from "../data";
import { C } from "../theme";

function Ring({ wins, losses }: { wins: number; losses: number }) {
  const total = wins + losses;
  const pct = total ? wins / total : 0;
  return (
    <View style={s.ringWrap}>
      <View style={s.ringOuter}>
        <View style={s.ringInner}>
          <Text style={s.ringText}>{wins}-{losses}</Text>
        </View>
      </View>
      <Text style={s.ringCaption}>{Math.round(pct * 100)}% WIN RATE</Text>
    </View>
  );
}

export default function Analytics() {
  const p = APP_DATA.performance;
  const settled = p.wins + p.losses + p.pushes;
  const winRate = p.wins + p.losses ? p.wins / (p.wins + p.losses) : 0;

  const spread = APP_DATA.forwardPicks.filter(
    (x) => x.market === "spread" && ["win", "loss", "push"].includes(x.result?.toLowerCase() ?? "")
  );
  const totals = APP_DATA.forwardPicks.filter(
    (x) => x.market === "total" && ["win", "loss", "push"].includes(x.result?.toLowerCase() ?? "")
  );

  const record = (xs: typeof APP_DATA.forwardPicks) => {
    const w = xs.filter((x) => x.result?.toLowerCase() === "win").length;
    const l = xs.filter((x) => x.result?.toLowerCase() === "loss").length;
    return `${w}-${l}`;
  };

  return (
    <SafeAreaView style={s.page}>
      <ScrollView contentContainerStyle={s.content}>
        <BrandHeader />
        <Text style={s.title}>Performance</Text>
        <Text style={s.sub}>This Week</Text>

        <View style={s.summary}>
          <View style={s.cell}>
            <Text style={s.label}>WIN RATE</Text>
            <Text style={[s.big, { color: C.gold }]}>
              {(winRate * 100).toFixed(1)}%
            </Text>
            <Text style={s.small}>{p.wins} of {p.wins + p.losses}</Text>
          </View>
          <View style={s.vline} />
          <View style={s.cell}>
            <Text style={s.label}>PROFIT</Text>
            <Text style={[s.big, { color: C.green }]}>
              {signed(p.forwardUnits, 2)}u
            </Text>
          </View>
          <View style={s.vline} />
          <View style={s.cell}>
            <Text style={s.label}>BETS</Text>
            <Text style={s.big}>{settled}</Text>
          </View>
        </View>

        <View style={s.chartCard}>
          <View style={s.chartHead}>
            <Text style={s.cardTitle}>▥  Bankroll Trend</Text>
            <View style={s.profitPill}>
              <Text style={s.profitPillText}>{signed(p.forwardUnits, 2)}u</Text>
            </View>
          </View>

          <View style={s.chart}>
            <View style={s.gridLine} />
            <View style={[s.point, { left: "6%", bottom: 26 }]} />
            <View style={[s.point, { left: "37%", bottom: 55, backgroundColor: C.green }]} />
            <View style={[s.point, { left: "64%", bottom: 34, backgroundColor: C.red }]} />
            <View style={[s.point, { left: "91%", bottom: 69, backgroundColor: C.green }]} />
            <View style={s.trend1} />
            <View style={s.trend2} />
            <View style={s.trend3} />
          </View>
        </View>

        <View style={s.twoCol}>
          <View style={s.card}>
            <Text style={s.cardTitle}>Results Breakdown</Text>
            <Ring wins={p.wins} losses={p.losses} />
            <View style={s.legend}>
              <Text style={[s.legendText, { color: C.green }]}>● Wins {p.wins}</Text>
              <Text style={[s.legendText, { color: C.red }]}>● Losses {p.losses}</Text>
            </View>
          </View>

          <View style={s.card}>
            <Text style={s.cardTitle}>Market Split</Text>
            <View style={s.marketBox}>
              <Text style={s.marketLabel}>🏈 Spread</Text>
              <Text style={[s.marketRecord, { color: C.red }]}>{record(spread)}</Text>
            </View>
            <View style={s.marketBox}>
              <Text style={s.marketLabel}>▥ Totals</Text>
              <Text style={[s.marketRecord, { color: C.green }]}>{record(totals)}</Text>
            </View>
          </View>
        </View>

        <View style={s.best}>
          <Text style={s.bestTitle}>🏆  Forward-Test Summary</Text>
          <Text style={s.bestText}>
            Average CLV: {p.averageClvPoints == null ? "—" : `${signed(p.averageClvPoints, 2)} pts`}
          </Text>
          <Text style={s.bestText}>
            Positive CLV: {p.clvCount ? `${Math.round((p.positiveClvCount / p.clvCount) * 100)}%` : "—"}
          </Text>
        </View>
      </ScrollView>

      <BottomNav active="performance" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 100 },

  title: { color: C.text, fontSize: 36, fontWeight: "900", marginTop: 21 },
  sub: { color: C.muted, fontSize: 15, marginTop: -1, marginBottom: 14 },

  summary: {
    flexDirection: "row",
    borderWidth: 1,
    borderColor: C.gold,
    borderRadius: 15,
    paddingVertical: 15,
    backgroundColor: "#11110E",
  },
  cell: { flex: 1, alignItems: "center" },
  label: { color: C.muted, fontSize: 8, fontWeight: "900" },
  big: { color: C.text, fontSize: 22, fontWeight: "900", marginTop: 4 },
  small: { color: C.muted, fontSize: 8, marginTop: 2 },
  vline: { width: 1, backgroundColor: "#3A3528" },

  chartCard: {
    marginTop: 12,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 16,
    padding: 14,
  },
  chartHead: { flexDirection: "row", justifyContent: "space-between" },
  cardTitle: { color: C.text, fontSize: 13, fontWeight: "900" },
  profitPill: {
    backgroundColor: C.greenSoft,
    borderWidth: 1,
    borderColor: C.green,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  profitPillText: { color: C.green, fontSize: 10, fontWeight: "900" },

  chart: {
    height: 150,
    marginTop: 12,
    backgroundColor: "#0A0D10",
    borderRadius: 10,
    overflow: "hidden",
  },
  gridLine: {
    position: "absolute",
    left: 0, right: 0, top: "50%",
    height: 1,
    backgroundColor: "#20262C",
  },
  point: {
    position: "absolute",
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: C.gold,
    borderWidth: 2,
    borderColor: "#DADADA",
    zIndex: 2,
  },
  trend1: {
    position: "absolute",
    left: "8%", bottom: 31,
    width: "30%", height: 3,
    backgroundColor: C.gold,
    transform: [{ rotate: "-12deg" }],
  },
  trend2: {
    position: "absolute",
    left: "38%", bottom: 48,
    width: "27%", height: 3,
    backgroundColor: C.gold,
    transform: [{ rotate: "10deg" }],
  },
  trend3: {
    position: "absolute",
    left: "64%", bottom: 49,
    width: "29%", height: 3,
    backgroundColor: C.gold,
    transform: [{ rotate: "-11deg" }],
  },

  twoCol: { flexDirection: "row", gap: 9, marginTop: 10 },
  card: {
    flex: 1,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 15,
    padding: 12,
  },
  ringWrap: { alignItems: "center", marginTop: 13 },
  ringOuter: {
    width: 92, height: 92, borderRadius: 46,
    borderWidth: 15, borderColor: C.green,
    borderLeftColor: C.red,
    alignItems: "center", justifyContent: "center",
  },
  ringInner: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: C.panel2,
    alignItems: "center", justifyContent: "center",
  },
  ringText: { color: C.text, fontWeight: "900", fontSize: 17 },
  ringCaption: { color: C.muted, fontSize: 7, fontWeight: "900", marginTop: 6 },
  legend: { gap: 4, marginTop: 9 },
  legendText: { fontSize: 10, fontWeight: "800" },

  marketBox: {
    backgroundColor: C.panel2,
    borderRadius: 10,
    padding: 11,
    marginTop: 10,
  },
  marketLabel: { color: C.muted, fontSize: 10, fontWeight: "800" },
  marketRecord: { fontSize: 17, fontWeight: "900", marginTop: 3 },

  best: {
    marginTop: 10,
    borderWidth: 1,
    borderColor: C.gold,
    borderRadius: 14,
    padding: 13,
    backgroundColor: "#151309",
  },
  bestTitle: { color: C.gold, fontWeight: "900", fontSize: 12 },
  bestText: { color: C.text, fontSize: 11, marginTop: 6 },
});
