import {
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import BottomNav from "../components/BottomNav";
import BrandHeader from "../components/BrandHeader";
import { APP_DATA, oddsText, signed, teamLogo } from "../data";
import { C } from "../theme";
import type { ForwardPick } from "../types";

function ResultCard({ pick }: { pick: ForwardPick }) {
  const win = pick.result?.toLowerCase() === "win";
  const loss = pick.result?.toLowerCase() === "loss";
  const push = pick.result?.toLowerCase() === "push";

  const fg = win ? C.green : loss ? C.red : push ? C.gray : C.blue;
  const bg = win ? C.greenSoft : loss ? C.redSoft : C.panel2;
  const label = win ? "WIN" : loss ? "LOSS" : push ? "PUSH" : "PENDING";

  const parts = pick.gameId.split("_");
  const away = parts[2] ?? "";
  const home = parts[3] ?? "";

  return (
    <View style={[s.resultCard, { borderLeftColor: fg }]}>
      <View style={s.resultTop}>
        <View style={[s.badge, { backgroundColor: bg }]}>
          <Text style={[s.badgeText, { color: fg }]}>{label}</Text>
        </View>
        <Text style={[s.profit, { color: fg }]}>
          {pick.settlementProfitUnits == null
            ? "—"
            : `${signed(pick.settlementProfitUnits, 2)}u`}
        </Text>
      </View>

      <View style={s.matchRow}>
        <Image source={{ uri: teamLogo(away) }} style={s.logo} />
        <View style={{ flex: 1 }}>
          <Text style={s.match}>{away} @ {home}</Text>
          <Text style={s.pick}>
            {pick.market === "spread"
              ? `${pick.pick} ${pick.line > 0 ? "+" : ""}${pick.line}`
              : `${pick.pick} ${pick.line.toFixed(1)}`}
          </Text>
        </View>
        <Image source={{ uri: teamLogo(home) }} style={s.logo} />
      </View>

      {pick.awayScore != null && pick.homeScore != null && (
        <Text style={s.final}>
          Final  {away} {pick.awayScore.toFixed(0)} – {pick.homeScore.toFixed(0)} {home}
        </Text>
      )}

      <View style={s.metaRow}>
        <View>
          <Text style={s.metaLabel}>ODDS</Text>
          <Text style={s.metaValue}>{oddsText(pick.odds)}</Text>
        </View>
        <View>
          <Text style={s.metaLabel}>EDGE</Text>
          <Text style={s.metaValue}>
            {pick.edge == null ? "—" : `${signed(pick.edge * 100, 2)}%`}
          </Text>
        </View>
        <View>
          <Text style={s.metaLabel}>CLV</Text>
          <Text
            style={[
              s.metaValue,
              (pick.clvPointsVsConsensus ?? 0) > 0 && { color: C.green },
            ]}
          >
            {pick.clvPointsVsConsensus == null
              ? "—"
              : `${signed(pick.clvPointsVsConsensus, 2)} pts`}
          </Text>
        </View>
        <View>
          <Text style={s.metaLabel}>BOOK</Text>
          <Text style={s.metaValue}>{pick.book}</Text>
        </View>
      </View>
    </View>
  );
}

export default function Results() {
  const p = APP_DATA.performance;
  const settled = APP_DATA.forwardPicks.filter((x) =>
    ["win", "loss", "push"].includes(x.result?.toLowerCase() ?? "")
  );

  const risked = settled.length;
  const roi = risked ? p.forwardUnits / risked : 0;

  return (
    <SafeAreaView style={s.page}>
      <FlatList
        data={settled}
        keyExtractor={(x, i) => `${x.gameId}-${x.market}-${x.pick}-${i}`}
        renderItem={({ item }) => <ResultCard pick={item} />}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        contentContainerStyle={s.content}
        ListHeaderComponent={
          <>
            <BrandHeader />
            <Text style={s.title}>Results</Text>
            <Text style={s.sub}>Settled Picks</Text>

            <View style={s.summary}>
              <View style={s.sumCell}>
                <Text style={s.sumLabel}>RECORD</Text>
                <Text style={[s.sumValue, { color: C.gold }]}>
                  {p.wins}-{p.losses}{p.pushes ? `-${p.pushes}` : ""}
                </Text>
              </View>
              <View style={s.vline} />
              <View style={s.sumCell}>
                <Text style={s.sumLabel}>UNITS</Text>
                <Text style={[s.sumValue, { color: C.green }]}>
                  {signed(p.forwardUnits, 2)}u
                </Text>
              </View>
              <View style={s.vline} />
              <View style={s.sumCell}>
                <Text style={s.sumLabel}>ROI</Text>
                <Text style={[s.sumValue, { color: C.green }]}>
                  {signed(roi * 100, 1)}%
                </Text>
              </View>
            </View>

            <View style={s.filters}>
              <View style={[s.filter, s.filterActive]}><Text style={s.filterActiveText}>All</Text></View>
              <View style={s.filter}><Text style={s.filterText}>Wins</Text></View>
              <View style={s.filter}><Text style={s.filterText}>Losses</Text></View>
              <View style={s.filter}><Text style={s.filterText}>Pending</Text></View>
            </View>
          </>
        }
      />

      <BottomNav active="results" />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 100 },

  title: { color: C.text, fontSize: 38, fontWeight: "900", marginTop: 21 },
  sub: { color: C.muted, fontSize: 15, marginTop: -2, marginBottom: 14 },

  summary: {
    flexDirection: "row",
    borderWidth: 1,
    borderColor: C.gold,
    borderRadius: 15,
    paddingVertical: 15,
    backgroundColor: "#11110E",
    shadowColor: C.gold,
    shadowOpacity: 0.16,
    shadowRadius: 9,
  },
  sumCell: { flex: 1, alignItems: "center" },
  sumLabel: { color: C.muted, fontSize: 8, fontWeight: "900" },
  sumValue: { fontSize: 23, fontWeight: "900", marginTop: 4 },
  vline: { width: 1, backgroundColor: "#3A3528" },

  filters: { flexDirection: "row", gap: 7, marginVertical: 14 },
  filter: {
    flex: 1,
    backgroundColor: C.panel2,
    borderRadius: 99,
    paddingVertical: 9,
    alignItems: "center",
    borderWidth: 1,
    borderColor: C.line,
  },
  filterActive: { backgroundColor: C.gold, borderColor: C.gold },
  filterText: { color: C.muted, fontSize: 10, fontWeight: "800" },
  filterActiveText: { color: "#17120A", fontSize: 10, fontWeight: "900" },

  resultCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderLeftWidth: 4,
    borderRadius: 16,
    padding: 13,
  },
  resultTop: { flexDirection: "row", justifyContent: "space-between" },
  badge: { borderRadius: 99, paddingHorizontal: 11, paddingVertical: 5 },
  badgeText: { fontSize: 9, fontWeight: "900" },
  profit: { fontSize: 20, fontWeight: "900" },

  matchRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 9 },
  logo: { width: 42, height: 42, resizeMode: "contain" },
  match: { color: C.text, fontSize: 17, fontWeight: "900" },
  pick: { color: C.text, fontSize: 13, fontWeight: "800", marginTop: 2 },
  final: { color: C.muted, fontSize: 10, marginTop: 7 },

  metaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: C.line,
    paddingTop: 10,
  },
  metaLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  metaValue: { color: C.text, fontSize: 10, fontWeight: "800", marginTop: 3 },
});
