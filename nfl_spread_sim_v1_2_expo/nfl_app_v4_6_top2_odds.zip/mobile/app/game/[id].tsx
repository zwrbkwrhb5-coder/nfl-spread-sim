import { router, useLocalSearchParams } from "expo-router";
import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  getGame,
  lineText,
  oddsText,
  pct,
  projectedScore,
  signed,
  teamLogo,
} from "../../data";
import { C } from "../../theme";
import type { MarketPick } from "../../types";

function MarketCard({ p }: { p: MarketPick }) {
  return (
    <View style={[s.marketCard, p.qualifies && { borderColor: C.gold }]}>
      <View style={s.marketTop}>
        <View>
          <Text style={s.marketLabel}>{p.market.toUpperCase()}</Text>
          <Text style={s.marketPick}>
            {lineText(p.market, p.pick, p.line)} {oddsText(p.odds)}
          </Text>
          <Text style={s.book}>{p.book}</Text>
        </View>
        <View style={[s.badge, { backgroundColor: p.qualifies ? C.greenSoft : C.panel3 }]}>
          <Text style={[s.badgeText, { color: p.qualifies ? C.green : C.muted }]}>
            {p.qualifies ? "QUALIFIED" : "PASS"}
          </Text>
        </View>
      </View>

      <View style={s.metrics}>
        <View style={s.metric}>
          <Text style={s.metricLabel}>MODEL PROB</Text>
          <Text style={s.metricValue}>{pct(p.selectedProbability)}</Text>
        </View>
        <View style={s.metric}>
          <Text style={s.metricLabel}>BREAK-EVEN</Text>
          <Text style={s.metricValue}>{pct(p.breakEven)}</Text>
        </View>
        <View style={s.metric}>
          <Text style={s.metricLabel}>EDGE</Text>
          <Text style={[s.metricValue, { color: p.qualifies ? C.green : C.muted }]}>
            {signed((p.edge ?? 0) * 100, 2)}%
          </Text>
        </View>
      </View>

      {p.oddsBoard.length > 0 && (
        <View style={s.oddsBoard}>
          <View style={s.oddsHead}>
            <Text style={s.oddsTitle}>BEST ODDS FOR THIS PLAY</Text>
            <Text style={s.oddsSub}>LINE + PRICE</Text>
          </View>

          {p.oddsBoard.slice(0, 2).map((q, qi) => (
            <View
              key={`${q.book}-${q.line}-${q.odds}-${qi}`}
              style={[
                s.oddsRow,
                q.selected && s.oddsRowSelected,
              ]}
            >
              <View style={{ flex: 1 }}>
                <Text style={[s.oddsBook, qi === 0 && { color: C.gold }]}>
                  {qi === 0 ? "★ #1 " : "#2 "}{q.book}
                </Text>
                <Text style={s.oddsLine}>
                  {lineText(p.market, p.pick, q.line)}
                </Text>
              </View>

              <View style={s.oddsCol}>
                <Text style={s.oddsColLabel}>ODDS</Text>
                <Text style={[s.oddsNumber, qi === 0 && { color: C.gold }]}>
                  {oddsText(q.odds)}
                </Text>
              </View>

              <View style={s.oddsCol}>
                <Text style={s.oddsColLabel}>EDGE</Text>
                <Text style={[s.oddsNumber, qi === 0 && { color: C.green }]}>
                  {q.edge == null ? "—" : `${signed(q.edge * 100, 2)}%`}
                </Text>
              </View>
            </View>
          ))}

          <Text style={s.oddsHelp}>
            #1 and #2 are the two best available quotes for this exact model play, ranked by model edge using both line and juice.
          </Text>
        </View>
      )}
    </View>
  );
}

export default function GameDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const g = getGame(String(id));
  if (!g) return null;

  const score = projectedScore(g);

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <Pressable onPress={() => router.back()} style={s.back}>
        <Text style={s.backText}>‹</Text>
      </Pressable>

      <Text style={s.brand}>NFL <Text style={{ color: C.gold }}>SIM</Text></Text>

      <View style={s.match}>
        <View style={s.team}>
          <Image source={{ uri: teamLogo(g.away) }} style={s.heroLogo} />
          <Text style={s.teamName}>{g.away}</Text>
        </View>
        <Text style={s.at}>@</Text>
        <View style={s.team}>
          <Image source={{ uri: teamLogo(g.home) }} style={s.heroLogo} />
          <Text style={s.teamName}>{g.home}</Text>
        </View>
      </View>

      {score && (
        <View style={s.scoreCard}>
          <Text style={s.scoreTitle}>MODEL PROJECTED SCORE</Text>
          <Text style={s.score}>
            {g.away} {score.away.toFixed(0)}  –  {score.home.toFixed(0)} {g.home}
          </Text>
          <Text style={s.total}>Projected total {g.modelTotal?.toFixed(1)}</Text>
        </View>
      )}

      <Text style={s.section}>CURRENT MARKETS</Text>
      {g.spread && <MarketCard p={g.spread} />}
      {g.total && <MarketCard p={g.total} />}

      {g.shadowTotal && (
        <>
          <Text style={s.section}>RESEARCH ONLY</Text>
          <View style={s.shadow}>
            <Text style={s.shadowTitle}>Totals Shadow Model</Text>
            <Text style={s.shadowValue}>
              {g.shadowTotal.direction} • {g.shadowTotal.shadowTotal.toFixed(1)}
            </Text>
            <Text style={s.shadowText}>
              Historical market timing used closing lines, so this signal remains separate from production picks.
            </Text>
          </View>
        </>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 17, paddingBottom: 40 },
  back: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: C.panel2,
    alignItems: "center", justifyContent: "center",
  },
  backText: { color: C.text, fontSize: 28, lineHeight: 30 },
  brand: {
    color: C.text, fontSize: 24, fontWeight: "900",
    fontStyle: "italic", textAlign: "center", marginTop: -34,
  },

  match: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    marginTop: 25, gap: 16,
  },
  team: { alignItems: "center" },
  heroLogo: { width: 100, height: 100, resizeMode: "contain" },
  teamName: { color: C.text, fontSize: 18, fontWeight: "900", marginTop: 4 },
  at: { color: C.gold, fontSize: 23, fontWeight: "900" },

  scoreCard: {
    backgroundColor: C.panel,
    borderWidth: 1, borderColor: C.gold,
    borderRadius: 17, padding: 15, marginTop: 18,
    alignItems: "center",
  },
  scoreTitle: { color: C.muted, fontSize: 8, fontWeight: "900" },
  score: { color: C.text, fontSize: 25, fontWeight: "900", marginTop: 6 },
  total: { color: C.gold, fontSize: 11, fontWeight: "800", marginTop: 4 },

  section: {
    color: C.muted, fontSize: 9, fontWeight: "900",
    letterSpacing: 1.2, marginTop: 21, marginBottom: 8,
  },
  marketCard: {
    backgroundColor: C.panel, borderWidth: 1, borderColor: C.line,
    borderRadius: 16, padding: 14, marginBottom: 10,
  },
  marketTop: { flexDirection: "row", justifyContent: "space-between" },
  marketLabel: { color: C.gold, fontSize: 8, fontWeight: "900" },
  marketPick: { color: C.text, fontSize: 20, fontWeight: "900", marginTop: 3 },
  book: { color: C.muted, fontSize: 10, marginTop: 2 },
  badge: { borderRadius: 99, paddingHorizontal: 8, paddingVertical: 5, height: 26 },
  badgeText: { fontSize: 8, fontWeight: "900" },
  metrics: { flexDirection: "row", gap: 8, marginTop: 14 },
  metric: {
    flex: 1, backgroundColor: C.panel2,
    borderRadius: 10, padding: 10,
  },
  metricLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  metricValue: { color: C.text, fontSize: 14, fontWeight: "900", marginTop: 3 },

  oddsBoard: {
    backgroundColor: "#090C0F",
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "#2B3137",
    padding: 10,
    marginTop: 12,
  },
  oddsHead: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingBottom: 6,
  },
  oddsTitle: { color: C.gold, fontSize: 8, fontWeight: "900", letterSpacing: 0.8 },
  oddsSub: { color: C.dim, fontSize: 7, fontWeight: "900" },
  oddsRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: "#22282E",
    paddingVertical: 9,
    paddingHorizontal: 5,
  },
  oddsRowSelected: {
    backgroundColor: "#171409",
    borderRadius: 8,
  },
  oddsBook: { color: C.text, fontSize: 10, fontWeight: "900" },
  oddsLine: { color: C.muted, fontSize: 9, marginTop: 2 },
  oddsCol: { width: 54, alignItems: "flex-end" },
  oddsColLabel: { color: C.dim, fontSize: 6, fontWeight: "900" },
  oddsNumber: { color: C.text, fontSize: 10, fontWeight: "900", marginTop: 2 },
  oddsHelp: { color: C.dim, fontSize: 8, lineHeight: 13, marginTop: 7 },

  shadow: {
    backgroundColor: "#1C1727",
    borderWidth: 1, borderColor: "#4B3A66",
    borderRadius: 15, padding: 14,
  },
  shadowTitle: { color: "#B79AF9", fontWeight: "900" },
  shadowValue: { color: C.text, fontSize: 20, fontWeight: "900", marginTop: 7 },
  shadowText: { color: "#C9BDEA", fontSize: 10, lineHeight: 16, marginTop: 8 },
});
