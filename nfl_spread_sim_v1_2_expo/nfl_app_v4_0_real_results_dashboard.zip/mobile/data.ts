import { APP_DATA } from "./generatedData";
import type { GameView, MarketPick } from "./types";

export { APP_DATA };
export type { GameView, MarketPick };

export const pct = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x) ? "—" : `${(x * 100).toFixed(digits)}%`;

export const signed = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x)
    ? "—"
    : `${x >= 0 ? "+" : ""}${x.toFixed(digits)}`;

export const oddsText = (x: number | null | undefined) =>
  x == null || Number.isNaN(x) ? "—" : `${x > 0 ? "+" : ""}${x.toFixed(0)}`;

export const lineText = (market: "spread" | "total", pick: string, line: number) => {
  if (market === "spread") return `${pick} ${signed(line)}`;
  return `${pick.toUpperCase()} ${line.toFixed(1)}`;
};

export const getGame = (id: string) =>
  APP_DATA.games.find((g) => g.id === id);

export const getQualifiedPicks = () =>
  APP_DATA.games
    .flatMap((g) =>
      [g.spread, g.total]
        .filter((x): x is MarketPick => Boolean(x && x.qualifies))
        .map((pick) => ({ game: g, pick }))
    )
    .sort((a, b) => (b.pick.edge ?? -999) - (a.pick.edge ?? -999));

export const modelSideFromMargin = (g: GameView) => {
  if (g.modelMargin == null) return "—";
  return g.modelMargin >= 0 ? g.home : g.away;
};

export const modelMarginText = (g: GameView) => {
  if (g.modelMargin == null) return "—";
  const side = g.modelMargin >= 0 ? g.home : g.away;
  return `${side} ${Math.abs(g.modelMargin).toFixed(1)}`;
};

export const maxAbs = (values: Array<number | null | undefined>, floor = 1) => {
  const xs = values.filter((x): x is number => x != null && Number.isFinite(x));
  return Math.max(floor, ...xs.map((x) => Math.abs(x)));
};
