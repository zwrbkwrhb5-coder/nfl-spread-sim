import { useLocalSearchParams } from "expo-router";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  getGame,
  lineText,
  oddsText,
  pct,
  signed,
} from "../../data";
import { C, marketStatus } from "../../theme";
import type { MarketPick } from "../../types";

function ProbabilityBar({
  probability,
  breakEven,
}: {
  probability: number | null;
  breakEven: number | null;
}) {
  const p = Math.min(1, Math.max(0, probability ?? 0));
  const be = Math.min(1, Math.max(0, breakEven ?? 0));

  return (
    <View style={s.probWrap}>
      <View style={s.probTrack}>
        <View style={[s.probFill, { width: `${p * 100}%` }]} />
        <View style={[s.beMarker, { left: `${be * 100}%` }]} />
      </View>
      <View style={s.probLabels}>
        <Text style={s.probText}>Model {pct(probability)}</Text>
        <Text style={s.probText}>Break-even {pct(breakEven)}</Text>
      </View>
    </View>
  );
}

function MarketCard({ pick }: { pick: MarketPick | null }) {
  if (!pick) {
    return (
      <View style={s.sectionCard}>
        <Text style={s.sectionTitle}>Market unavailable</Text>
      </View>
    );
  }

  const badge = marketStatus(pick.qualifies);

  return (
    <View style={s.sectionCard}>
      <View style={s.sectionTop}>
        <View>
          <Text style={s.eyebrow}>{pick.market.toUpperCase()}</Text>
          <Text style={s.marketPick}>
            {lineText(pick.market, pick.pick, pick.line)} {oddsText(pick.odds)}
          </Text>
          <Text style={s.book}>{pick.book}</Text>
        </View>
        <View style={[s.badge, { backgroundColor: badge.bg }]}>
          <Text style={[s.badgeText, { color: badge.fg }]}>{badge.label}</Text>
        </View>
      </View>

      <View style={s.metricGrid}>
        <View style={s.metric}>
          <Text style={s.metricLabel}>RAW</Text>
          <Text style={s.metricValue}>{pct(pick.rawProbability)}</Text>
        </View>
        <View style={s.metric}>
          <Text style={s.metricLabel}>CALIBRATED</Text>
          <Text style={s.metricValue}>{pct(pick.calibratedProbability)}</Text>
        </View>
        <View style={s.metric}>
          <Text style={s.metricLabel}>SELECTED</Text>
          <Text style={s.metricValue}>{pct(pick.selectedProbability)}</Text>
        </View>
        <View style={s.metric}>
          <Text style={s.metricLabel}>EDGE</Text>
          <Text
            style={[
              s.metricValue,
              pick.qualifies ? { color: C.green } : { color: C.muted },
            ]}
          >
            {signed((pick.edge ?? 0) * 100, 2)}%
          </Text>
        </View>
      </View>

      <ProbabilityBar
        probability={pick.selectedProbability}
        breakEven={pick.breakEven}
      />

      <Text style={s.quoteAge}>
        Quote age:{" "}
        {pick.quoteAgeMinutes == null
          ? "—"
          : `${pick.quoteAgeMinutes.toFixed(1)} min`}
      </Text>
    </View>
  );
}

export default function GameAnalysis() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const game = getGame(String(id));

  if (!game) {
    return (
      <View style={s.notFound}>
        <Text style={s.notFoundTitle}>Game not found</Text>
        <Text style={s.notFoundText}>
          Refresh the exported mobile data and try again.
        </Text>
      </View>
    );
  }

  const homeProjected =
    game.modelMargin == null
      ? null
      : game.modelMargin >= 0
      ? `${game.home} by ${game.modelMargin.toFixed(1)}`
      : `${game.away} by ${Math.abs(game.modelMargin).toFixed(1)}`;

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <View style={s.heroCard}>
        <Text style={s.week}>2026 • WEEK {game.week}</Text>
        <Text style={s.matchup}>{game.away} @ {game.home}</Text>
        <Text style={s.qbs}>
          {game.awayQB ?? "QB TBD"} vs {game.homeQB ?? "QB TBD"}
        </Text>

        <View style={s.heroGrid}>
          <View style={s.heroMetric}>
            <Text style={s.heroLabel}>MODEL MARGIN</Text>
            <Text style={s.heroValue}>{homeProjected ?? "—"}</Text>
          </View>
          <View style={s.heroMetric}>
            <Text style={s.heroLabel}>MODEL TOTAL</Text>
            <Text style={s.heroValue}>
              {game.modelTotal == null ? "—" : game.modelTotal.toFixed(1)}
            </Text>
          </View>
        </View>
      </View>

      <Text style={s.heading}>PRODUCTION MARKETS</Text>
      <MarketCard pick={game.spread} />
      <MarketCard pick={game.total} />

      {game.shadowTotal && (
        <>
          <Text style={s.heading}>MODEL LAB</Text>
          <View style={[s.sectionCard, { borderColor: "#443566" }]}>
            <View style={s.sectionTop}>
              <View>
                <Text style={[s.eyebrow, { color: C.purple }]}>
                  TOTALS SHADOW
                </Text>
                <Text style={s.marketPick}>
                  {game.shadowTotal.direction} •{" "}
                  {game.shadowTotal.shadowTotal.toFixed(1)}
                </Text>
              </View>
              <View style={[s.badge, { backgroundColor: C.purpleSoft }]}>
                <Text style={[s.badgeText, { color: C.purple }]}>RESEARCH</Text>
              </View>
            </View>

            <View style={s.metricGrid}>
              <View style={s.metric}>
                <Text style={s.metricLabel}>CONSENSUS</Text>
                <Text style={s.metricValue}>
                  {game.shadowTotal.currentConsensusTotal.toFixed(1)}
                </Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>SHADOW</Text>
                <Text style={s.metricValue}>
                  {game.shadowTotal.shadowTotal.toFixed(1)}
                </Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>GAP</Text>
                <Text style={[s.metricValue, { color: C.purple }]}>
                  {signed(game.shadowTotal.gap, 2)}
                </Text>
              </View>
              <View style={s.metric}>
                <Text style={s.metricLabel}>BOOKS</Text>
                <Text style={s.metricValue}>
                  {game.shadowTotal.booksInConsensus}
                </Text>
              </View>
            </View>

            <View style={s.warning}>
              <Text style={s.warningText}>
                Shadow only. Historical stack was trained on closing lines;
                this current-market proxy is not timing-matched to training.
              </Text>
            </View>
          </View>
        </>
      )}

      <View style={s.legend}>
        <Text style={s.legendTitle}>STATUS</Text>
        <Text style={s.legendText}>
          Green = production qualifier • Purple = research only • Gray = no bet
        </Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 40 },
  heroCard: {
    backgroundColor: "#0F1724",
    borderWidth: 1,
    borderColor: "#233149",
    borderRadius: 22,
    padding: 20,
    marginBottom: 24,
  },
  week: { color: C.gold, fontSize: 10, fontWeight: "900", letterSpacing: 1.5 },
  matchup: { color: C.text, fontSize: 30, fontWeight: "900", marginTop: 5 },
  qbs: { color: C.muted, marginTop: 6 },
  heroGrid: { flexDirection: "row", gap: 10, marginTop: 20 },
  heroMetric: {
    flex: 1,
    backgroundColor: "#151E2D",
    borderRadius: 14,
    padding: 13,
  },
  heroLabel: { color: C.dim, fontSize: 8, fontWeight: "900" },
  heroValue: { color: C.text, fontSize: 16, fontWeight: "900", marginTop: 5 },
  heading: {
    color: C.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
    marginBottom: 9,
    marginTop: 4,
  },
  sectionCard: {
    backgroundColor: C.panel,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: C.line,
    padding: 17,
    marginBottom: 12,
  },
  sectionTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  eyebrow: { color: C.gold, fontSize: 9, fontWeight: "900", letterSpacing: 1.2 },
  marketPick: { color: C.text, fontSize: 19, fontWeight: "900", marginTop: 4 },
  book: { color: C.muted, fontSize: 11, marginTop: 3 },
  badge: { borderRadius: 99, paddingHorizontal: 9, paddingVertical: 5 },
  badgeText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },
  metricGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 18,
    gap: 8,
  },
  metric: {
    width: "48%",
    backgroundColor: C.panel2,
    borderRadius: 12,
    padding: 11,
  },
  metricLabel: { color: C.dim, fontSize: 8, fontWeight: "900" },
  metricValue: { color: C.text, fontSize: 15, fontWeight: "900", marginTop: 4 },
  probWrap: { marginTop: 17 },
  probTrack: {
    height: 8,
    borderRadius: 4,
    backgroundColor: "#202838",
    overflow: "hidden",
    position: "relative",
  },
  probFill: { height: "100%", backgroundColor: C.green },
  beMarker: {
    position: "absolute",
    top: -2,
    bottom: -2,
    width: 2,
    backgroundColor: C.gold,
  },
  probLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 7,
  },
  probText: { color: C.muted, fontSize: 10 },
  quoteAge: { color: C.dim, fontSize: 9, marginTop: 12 },
  warning: {
    marginTop: 15,
    backgroundColor: C.purpleSoft,
    borderRadius: 12,
    padding: 11,
  },
  warningText: { color: "#D8CCFF", fontSize: 11, lineHeight: 17 },
  legend: {
    backgroundColor: C.panel,
    borderRadius: 16,
    padding: 14,
    marginTop: 10,
  },
  legendTitle: { color: C.dim, fontSize: 9, fontWeight: "900" },
  legendText: { color: C.muted, fontSize: 11, marginTop: 4, lineHeight: 17 },
  notFound: {
    flex: 1,
    backgroundColor: C.bg,
    alignItems: "center",
    justifyContent: "center",
    padding: 30,
  },
  notFoundTitle: { color: C.text, fontSize: 22, fontWeight: "900" },
  notFoundText: { color: C.muted, marginTop: 7, textAlign: "center" },
});
