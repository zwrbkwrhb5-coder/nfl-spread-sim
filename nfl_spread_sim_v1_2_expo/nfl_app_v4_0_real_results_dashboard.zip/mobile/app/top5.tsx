import { Link } from "expo-router";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { getQualifiedPicks, lineText, oddsText, pct, signed } from "../data";
import { C } from "../theme";

export default function QualifiedPicks() {
  const picks = getQualifiedPicks();

  return (
    <View style={s.page}>
      <View style={s.hero}>
        <Text style={s.kicker}>PRODUCTION SIGNALS</Text>
        <Text style={s.title}>Qualified Picks</Text>
        <Text style={s.sub}>
          Current v3.1 selections ranked by calibrated edge.
        </Text>
      </View>

      <FlatList
        data={picks}
        keyExtractor={(x) => `${x.game.id}-${x.pick.market}`}
        contentContainerStyle={s.list}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={s.emptyTitle}>No qualifying plays</Text>
            <Text style={s.emptyText}>
              The model will show PASS rather than lower the threshold to create action.
            </Text>
          </View>
        }
        renderItem={({ item, index }) => (
          <Link
            href={{ pathname: "/game/[id]", params: { id: item.game.id } }}
            asChild
          >
            <Pressable style={s.card}>
              <View style={s.rankCircle}>
                <Text style={s.rank}>#{index + 1}</Text>
              </View>

              <View style={{ flex: 1 }}>
                <View style={s.topRow}>
                  <Text style={s.match}>
                    {item.game.away} @ {item.game.home}
                  </Text>
                  <View style={s.greenPill}>
                    <Text style={s.greenPillText}>QUALIFIED</Text>
                  </View>
                </View>

                <Text style={s.pick}>
                  {lineText(item.pick.market, item.pick.pick, item.pick.line)}{" "}
                  {oddsText(item.pick.odds)}
                </Text>
                <Text style={s.book}>{item.pick.book}</Text>

                <View style={s.metrics}>
                  <View>
                    <Text style={s.metricLabel}>PROB</Text>
                    <Text style={s.metricValue}>
                      {pct(item.pick.selectedProbability)}
                    </Text>
                  </View>
                  <View>
                    <Text style={s.metricLabel}>BREAK EVEN</Text>
                    <Text style={s.metricValue}>
                      {pct(item.pick.breakEven)}
                    </Text>
                  </View>
                  <View>
                    <Text style={s.metricLabel}>EDGE</Text>
                    <Text style={[s.metricValue, { color: C.green }]}>
                      {signed((item.pick.edge ?? 0) * 100, 2)}%
                    </Text>
                  </View>
                </View>
              </View>
            </Pressable>
          </Link>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  hero: { padding: 18, paddingBottom: 4 },
  kicker: {
    color: C.gold,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  title: { color: C.text, fontSize: 30, fontWeight: "900", marginTop: 4 },
  sub: { color: C.muted, marginTop: 5 },
  list: { padding: 16, gap: 12, paddingBottom: 36 },
  card: {
    flexDirection: "row",
    gap: 13,
    backgroundColor: C.panel,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: C.line,
    padding: 16,
  },
  rankCircle: {
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: C.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  rank: { color: C.gold, fontSize: 16, fontWeight: "900" },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 8,
    alignItems: "center",
  },
  match: { color: C.text, fontSize: 17, fontWeight: "900" },
  greenPill: {
    backgroundColor: C.greenSoft,
    borderRadius: 99,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  greenPillText: { color: C.green, fontSize: 8, fontWeight: "900" },
  pick: { color: C.text, fontWeight: "900", fontSize: 16, marginTop: 8 },
  book: { color: C.muted, fontSize: 11, marginTop: 3 },
  metrics: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14,
  },
  metricLabel: { color: C.dim, fontSize: 8, fontWeight: "900" },
  metricValue: { color: C.text, fontWeight: "900", fontSize: 13, marginTop: 3 },
  empty: {
    backgroundColor: C.panel,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: C.line,
    padding: 22,
  },
  emptyTitle: { color: C.text, fontSize: 18, fontWeight: "900" },
  emptyText: { color: C.muted, marginTop: 7, lineHeight: 20 },
});
