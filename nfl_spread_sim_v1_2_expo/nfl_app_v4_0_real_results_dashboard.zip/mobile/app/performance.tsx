import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { APP_DATA, oddsText, signed } from "../data";
import { C } from "../theme";
import type { HistoricalMetric } from "../types";

function Stat({
  value,
  label,
  color,
}: {
  value: string;
  label: string;
  color?: string;
}) {
  return (
    <View style={s.stat}>
      <Text style={[s.statValue, color ? { color } : undefined]}>{value}</Text>
      <Text style={s.statLabel}>{label}</Text>
    </View>
  );
}

function MaeBars({ metric }: { metric: HistoricalMetric }) {
  const max = Math.max(
    metric.marketMae,
    metric.marketCalibratedMae,
    metric.baseModelMae,
    metric.stackMae,
  );

  const rows = [
    ["Market", metric.marketMae, C.gold],
    ["Market calibrated", metric.marketCalibratedMae, C.blue],
    ["Standalone", metric.baseModelMae, C.red],
    ["Market + model", metric.stackMae, C.green],
  ] as const;

  return (
    <View style={s.metricCard}>
      <View style={s.metricHeader}>
        <Text style={s.metricTitle}>{metric.market.toUpperCase()}</Text>
        <Text style={s.gamesLabel}>{metric.games} games</Text>
      </View>
      <Text style={s.metricSub}>Lower MAE is better</Text>

      {rows.map(([label, value, color]) => (
        <View key={label} style={s.barRow}>
          <View style={s.barLabels}>
            <Text style={s.barLabel}>{label}</Text>
            <Text style={s.barValue}>{value.toFixed(2)}</Text>
          </View>
          <View style={s.track}>
            <View
              style={[
                s.fill,
                {
                  backgroundColor: color,
                  width: `${Math.max(8, (value / max) * 100)}%`,
                },
              ]}
            />
          </View>
        </View>
      ))}

      <View
        style={[
          s.researchStatus,
          {
            backgroundColor:
              metric.market === "total" ? C.purpleSoft : C.panel2,
          },
        ]}
      >
        <Text
          style={[
            s.researchStatusText,
            {
              color: metric.market === "total" ? C.purple : C.muted,
            },
          ]}
        >
          {metric.market === "total"
            ? "Small incremental total signal • shadow testing"
            : "Sportsbook market remains stronger"}
        </Text>
      </View>
    </View>
  );
}

export default function Performance() {
  const p = APP_DATA.performance;

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <Text style={s.kicker}>FORWARD TEST</Text>
      <Text style={s.title}>Performance</Text>
      <Text style={s.sub}>
        Prospective results, closing-line value, and historical model diagnostics.
      </Text>

      <View style={s.statsRow}>
        <Stat value={`${p.qualifiedCount}`} label="QUALIFIED" color={C.green} />
        <Stat
          value={`${p.wins}-${p.losses}${p.pushes ? `-${p.pushes}` : ""}`}
          label="SETTLED"
        />
        <Stat
          value={signed(p.forwardUnits, 2)}
          label="UNITS"
          color={p.forwardUnits > 0 ? C.green : p.forwardUnits < 0 ? C.red : C.text}
        />
      </View>

      <View style={s.statsRow}>
        <Stat value={`${p.clvCount}`} label="CLV SAMPLES" color={C.blue} />
        <Stat
          value={
            p.averageClvPoints == null
              ? "—"
              : signed(p.averageClvPoints, 2)
          }
          label="AVG CLV PTS"
          color={
            (p.averageClvPoints ?? 0) > 0
              ? C.green
              : (p.averageClvPoints ?? 0) < 0
              ? C.red
              : C.text
          }
        />
        <Stat
          value={
            p.clvCount
              ? `${Math.round((p.positiveClvCount / p.clvCount) * 100)}%`
              : "—"
          }
          label="POSITIVE CLV"
        />
      </View>

      <Text style={s.sectionHeading}>FORWARD PICKS</Text>

      {APP_DATA.forwardPicks.map((pick) => {
        const clv = pick.clvPointsVsConsensus;
        const clvColor =
          clv == null ? C.muted : clv > 0 ? C.green : clv < 0 ? C.red : C.text;

        return (
          <View
            key={`${pick.gameId}-${pick.market}-${pick.pick}`}
            style={s.pickCard}
          >
            <View style={s.pickTop}>
              <View>
                <Text style={s.pickGame}>{pick.gameId.replaceAll("_", " ")}</Text>
                <Text style={s.pickLine}>
                  {pick.pick} {pick.line > 0 ? "+" : ""}
                  {pick.line} {oddsText(pick.odds)}
                </Text>
                <Text style={s.pickBook}>{pick.book}</Text>
              </View>
              <View style={s.forwardBadge}>
                <Text style={s.forwardBadgeText}>FORWARD TEST</Text>
              </View>
            </View>

            <View style={s.pickMetrics}>
              <View>
                <Text style={s.pickMetricLabel}>EDGE</Text>
                <Text style={s.pickMetricValue}>
                  {pick.edge == null ? "—" : `${signed(pick.edge * 100, 2)}%`}
                </Text>
              </View>
              <View>
                <Text style={s.pickMetricLabel}>CLOSE</Text>
                <Text style={s.pickMetricValue}>
                  {pick.closeConsensusLine == null
                    ? "—"
                    : pick.closeConsensusLine.toFixed(2)}
                </Text>
              </View>
              <View>
                <Text style={s.pickMetricLabel}>CLV</Text>
                <Text style={[s.pickMetricValue, { color: clvColor }]}>
                  {clv == null ? "—" : `${signed(clv, 2)} pts`}
                </Text>
              </View>
              <View>
                <Text style={s.pickMetricLabel}>RESULT</Text>
                <Text style={s.pickMetricValue}>
                  {pick.result?.toUpperCase() ?? "PENDING"}
                </Text>
              </View>
            </View>

            {pick.closeNote && (
              <Text style={s.note}>{pick.closeNote.replaceAll("_", " ")}</Text>
            )}
          </View>
        );
      })}

      <Text style={s.sectionHeading}>HISTORICAL FORECAST QUALITY</Text>
      {APP_DATA.historicalMetrics.map((m) => (
        <MaeBars key={m.market} metric={m} />
      ))}

      <View style={s.infoCard}>
        <Text style={s.infoTitle}>How to read this screen</Text>
        <Text style={s.infoText}>
          CLV is tracked prospectively. Historical MAE is diagnostic evidence,
          not a guarantee of betting profitability. The totals market-stack
          remains research-only because its historical market feature is a
          closing line while live snapshots are collected earlier.
        </Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 40 },
  kicker: { color: C.blue, fontSize: 10, fontWeight: "900", letterSpacing: 1.5 },
  title: { color: C.text, fontSize: 32, fontWeight: "900", marginTop: 4 },
  sub: { color: C.muted, marginTop: 5, lineHeight: 19, marginBottom: 18 },
  statsRow: { flexDirection: "row", gap: 8, marginBottom: 8 },
  stat: {
    flex: 1,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 15,
    padding: 13,
  },
  statValue: { color: C.text, fontSize: 19, fontWeight: "900" },
  statLabel: {
    color: C.dim,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 0.8,
    marginTop: 4,
  },
  sectionHeading: {
    color: C.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
    marginTop: 19,
    marginBottom: 9,
  },
  pickCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 17,
    padding: 15,
    marginBottom: 10,
  },
  pickTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  pickGame: { color: C.muted, fontSize: 10, fontWeight: "800" },
  pickLine: { color: C.text, fontSize: 17, fontWeight: "900", marginTop: 3 },
  pickBook: { color: C.muted, fontSize: 10, marginTop: 3 },
  forwardBadge: {
    backgroundColor: C.blueSoft,
    borderRadius: 99,
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  forwardBadgeText: { color: C.blue, fontSize: 8, fontWeight: "900" },
  pickMetrics: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 15,
  },
  pickMetricLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  pickMetricValue: { color: C.text, fontSize: 12, fontWeight: "900", marginTop: 3 },
  note: { color: C.amber, fontSize: 10, marginTop: 11 },
  metricCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
  },
  metricHeader: { flexDirection: "row", justifyContent: "space-between" },
  metricTitle: { color: C.text, fontSize: 18, fontWeight: "900" },
  gamesLabel: { color: C.dim, fontSize: 10 },
  metricSub: { color: C.muted, fontSize: 10, marginTop: 3, marginBottom: 12 },
  barRow: { marginBottom: 11 },
  barLabels: { flexDirection: "row", justifyContent: "space-between" },
  barLabel: { color: C.muted, fontSize: 10 },
  barValue: { color: C.text, fontWeight: "800", fontSize: 10 },
  track: {
    height: 8,
    backgroundColor: C.panel2,
    borderRadius: 5,
    overflow: "hidden",
    marginTop: 5,
  },
  fill: { height: "100%", borderRadius: 5 },
  researchStatus: { borderRadius: 11, padding: 10, marginTop: 4 },
  researchStatusText: { fontSize: 10, fontWeight: "800" },
  infoCard: {
    backgroundColor: C.blueSoft,
    borderRadius: 16,
    padding: 15,
    marginTop: 8,
  },
  infoTitle: { color: C.blue, fontWeight: "900" },
  infoText: { color: "#BDD8FA", fontSize: 11, lineHeight: 18, marginTop: 6 },
});
