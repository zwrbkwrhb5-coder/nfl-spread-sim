import { Link } from "expo-router";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  APP_DATA,
  lineText,
  modelMarginText,
  oddsText,
  pct,
  signed,
} from "../data";
import { C, marketStatus } from "../theme";
import type { GameView, MarketPick } from "../types";

function EdgeBar({ edge }: { edge: number | null }) {
  const pctWidth = Math.min(100, Math.max(0, ((edge ?? 0) / 0.05) * 100));
  return (
    <View style={s.edgeTrack}>
      <View style={[s.edgeFill, { width: `${pctWidth}%` }]} />
    </View>
  );
}

function MarketStrip({ pick }: { pick: MarketPick | null }) {
  if (!pick) {
    return (
      <View style={s.marketStrip}>
        <Text style={s.marketName}>MARKET</Text>
        <Text style={s.missing}>Unavailable</Text>
      </View>
    );
  }

  const badge = marketStatus(pick.qualifies);

  return (
    <View style={s.marketStrip}>
      <View style={{ flex: 1 }}>
        <View style={s.marketHeader}>
          <Text style={s.marketName}>{pick.market.toUpperCase()}</Text>
          <View style={[s.badge, { backgroundColor: badge.bg }]}>
            <Text style={[s.badgeText, { color: badge.fg }]}>{badge.label}</Text>
          </View>
        </View>
        <Text style={s.pickText}>
          {lineText(pick.market, pick.pick, pick.line)} {oddsText(pick.odds)}
        </Text>
        <Text style={s.bookText}>{pick.book}</Text>
      </View>

      <View style={s.edgeBox}>
        <Text style={s.edgeLabel}>EDGE</Text>
        <Text style={[s.edgeNumber, pick.qualifies && { color: C.green }]}>
          {signed((pick.edge ?? 0) * 100, 2)}%
        </Text>
      </View>
    </View>
  );
}

function GameCard({ game }: { game: GameView }) {
  return (
    <Link href={{ pathname: "/game/[id]", params: { id: game.id } }} asChild>
      <Pressable style={s.card}>
        <View style={s.cardTop}>
          <View>
            <Text style={s.matchup}>{game.away} @ {game.home}</Text>
            <Text style={s.meta}>Week {game.week} • Model snapshot</Text>
          </View>
          <View
            style={[
              s.gameStatus,
              {
                backgroundColor: game.qualifies ? C.greenSoft : C.panel2,
              },
            ]}
          >
            <Text
              style={[
                s.gameStatusText,
                { color: game.qualifies ? C.green : C.muted },
              ]}
            >
              {game.qualifies ? "PLAY" : "PASS"}
            </Text>
          </View>
        </View>

        <View style={s.projectionRow}>
          <View style={s.projectionCell}>
            <Text style={s.smallLabel}>MODEL MARGIN</Text>
            <Text style={s.bigValue}>{modelMarginText(game)}</Text>
          </View>
          <View style={s.projectionCell}>
            <Text style={s.smallLabel}>MODEL TOTAL</Text>
            <Text style={s.bigValue}>
              {game.modelTotal == null ? "—" : game.modelTotal.toFixed(1)}
            </Text>
          </View>
          <View style={s.projectionCell}>
            <Text style={s.smallLabel}>BEST EDGE</Text>
            <Text style={[s.bigValue, game.qualifies && { color: C.green }]}>
              {game.bestEdge == null ? "—" : `${signed(game.bestEdge * 100, 2)}%`}
            </Text>
          </View>
        </View>

        <EdgeBar edge={game.bestEdge} />

        <View style={s.divider} />
        <MarketStrip pick={game.spread} />
        <View style={s.thinDivider} />
        <MarketStrip pick={game.total} />

        {game.shadowTotal && (
          <View style={s.shadowRow}>
            <View style={s.shadowDot} />
            <Text style={s.shadowText}>
              Shadow total {game.shadowTotal.shadowTotal.toFixed(1)} •{" "}
              {game.shadowTotal.direction} •{" "}
              {signed(game.shadowTotal.gap, 1)} pts vs consensus
            </Text>
          </View>
        )}
      </Pressable>
    </Link>
  );
}

export default function Home() {
  const qualified = APP_DATA.performance.qualifiedCount;
  const clv = APP_DATA.performance.averageClvPoints;

  return (
    <SafeAreaView style={s.page} edges={["bottom"]}>
      <FlatList
        data={APP_DATA.games}
        keyExtractor={(g) => g.id}
        contentContainerStyle={s.list}
        ListHeaderComponent={
          <>
            <View style={s.hero}>
              <Text style={s.kicker}>
                2026 • WEEK {APP_DATA.week}
              </Text>
              <Text style={s.title}>NFL Model</Text>
              <Text style={s.sub}>
                Live market pricing, calibrated probabilities, forward testing
              </Text>
            </View>

            <View style={s.summaryRow}>
              <View style={s.summaryCard}>
                <Text style={s.summaryValue}>{APP_DATA.games.length}</Text>
                <Text style={s.summaryLabel}>GAMES</Text>
              </View>
              <View style={s.summaryCard}>
                <Text style={[s.summaryValue, { color: C.green }]}>
                  {qualified}
                </Text>
                <Text style={s.summaryLabel}>QUALIFIED</Text>
              </View>
              <View style={s.summaryCard}>
                <Text style={[s.summaryValue, { color: C.blue }]}>
                  {clv == null ? "—" : `${signed(clv, 2)}`}
                </Text>
                <Text style={s.summaryLabel}>AVG CLV</Text>
              </View>
            </View>

            <View style={s.navRow}>
              <Link href="/top5" asChild>
                <Pressable style={s.navButton}>
                  <Text style={s.navButtonTitle}>Qualified Picks</Text>
                  <Text style={s.navButtonSub}>Best current edges</Text>
                </Pressable>
              </Link>
              <Link href="/performance" asChild>
                <Pressable style={s.navButton}>
                  <Text style={s.navButtonTitle}>Performance</Text>
                  <Text style={s.navButtonSub}>CLV + model testing</Text>
                </Pressable>
              </Link>
            </View>

            {APP_DATA.games.length === 0 && (
              <View style={s.emptyCard}>
                <Text style={s.emptyTitle}>No exported model data yet</Text>
                <Text style={s.emptyText}>
                  Run the v4.0 export command from the project root, then reload Expo.
                </Text>
              </View>
            )}

            <Text style={s.sectionTitle}>ALL GAMES</Text>
          </>
        }
        renderItem={({ item }) => <GameCard game={item} />}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  list: { padding: 16, paddingBottom: 40 },
  hero: { paddingTop: 6, paddingBottom: 16 },
  kicker: {
    color: C.gold,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.7,
  },
  title: {
    color: C.text,
    fontSize: 36,
    fontWeight: "900",
    marginTop: 5,
  },
  sub: { color: C.muted, marginTop: 5, lineHeight: 20 },
  summaryRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  summaryCard: {
    flex: 1,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 16,
    padding: 14,
  },
  summaryValue: { color: C.text, fontSize: 22, fontWeight: "900" },
  summaryLabel: {
    color: C.dim,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.1,
    marginTop: 4,
  },
  navRow: { flexDirection: "row", gap: 10, marginBottom: 22 },
  navButton: {
    flex: 1,
    backgroundColor: C.red,
    borderRadius: 16,
    padding: 14,
  },
  navButtonTitle: { color: C.white, fontWeight: "900", fontSize: 14 },
  navButtonSub: { color: "#F3C9CB", fontSize: 11, marginTop: 3 },
  sectionTitle: {
    color: C.muted,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.4,
    marginBottom: 10,
  },
  card: {
    backgroundColor: C.panel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.line,
    padding: 17,
  },
  cardTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  matchup: { color: C.text, fontSize: 21, fontWeight: "900" },
  meta: { color: C.dim, fontSize: 11, marginTop: 4 },
  gameStatus: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 99,
  },
  gameStatusText: { fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  projectionRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 17,
  },
  projectionCell: { flex: 1 },
  smallLabel: {
    color: C.dim,
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 0.9,
  },
  bigValue: {
    color: C.text,
    fontWeight: "900",
    fontSize: 15,
    marginTop: 4,
  },
  edgeTrack: {
    height: 4,
    borderRadius: 2,
    backgroundColor: C.panel2,
    overflow: "hidden",
    marginTop: 12,
  },
  edgeFill: {
    height: "100%",
    backgroundColor: C.green,
    borderRadius: 2,
  },
  divider: { height: 1, backgroundColor: C.line, marginVertical: 15 },
  thinDivider: { height: 1, backgroundColor: "#1C2330", marginVertical: 10 },
  marketStrip: {
    flexDirection: "row",
    alignItems: "center",
  },
  marketHeader: { flexDirection: "row", gap: 7, alignItems: "center" },
  marketName: {
    color: C.dim,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.1,
  },
  badge: { paddingHorizontal: 7, paddingVertical: 3, borderRadius: 99 },
  badgeText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.6 },
  pickText: { color: C.text, fontWeight: "900", fontSize: 15, marginTop: 4 },
  bookText: { color: C.muted, fontSize: 11, marginTop: 2 },
  edgeBox: { alignItems: "flex-end", marginLeft: 12 },
  edgeLabel: { color: C.dim, fontSize: 8, fontWeight: "900" },
  edgeNumber: { color: C.text, fontSize: 16, fontWeight: "900", marginTop: 3 },
  missing: { color: C.dim, marginTop: 4 },
  shadowRow: {
    marginTop: 14,
    backgroundColor: C.purpleSoft,
    borderRadius: 12,
    padding: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  shadowDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: C.purple,
  },
  shadowText: { color: "#D8CCFF", fontSize: 11, fontWeight: "700", flex: 1 },
  emptyCard: {
    backgroundColor: C.amberSoft,
    borderWidth: 1,
    borderColor: "#5A4214",
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  emptyTitle: { color: C.amber, fontWeight: "900" },
  emptyText: { color: "#D7B66D", marginTop: 5, lineHeight: 18 },
});
