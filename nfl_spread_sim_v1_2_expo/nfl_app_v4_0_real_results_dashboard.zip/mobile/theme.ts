export const C = {
  bg: "#090B10",
  panel: "#111620",
  panel2: "#171D29",
  line: "#252D3A",
  text: "#F5F7FA",
  muted: "#8993A3",
  dim: "#647083",
  gold: "#E0B55D",
  goldSoft: "#2A2215",
  red: "#A5161D",
  green: "#32D583",
  greenSoft: "#0D2B20",
  purple: "#A78BFA",
  purpleSoft: "#231B3A",
  blue: "#60A5FA",
  blueSoft: "#15243A",
  amber: "#F59E0B",
  amberSoft: "#33250C",
  white: "#FFFFFF",
};

export const marketStatus = (qualifies: boolean) =>
  qualifies
    ? { label: "QUALIFIED", fg: C.green, bg: C.greenSoft }
    : { label: "NO BET", fg: C.muted, bg: C.panel2 };
