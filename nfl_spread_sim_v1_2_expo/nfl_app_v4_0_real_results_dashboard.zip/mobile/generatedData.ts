import type { AppSnapshot } from "./types";

export const APP_DATA = {
  generatedAt: "not-generated",
  season: 2026,
  week: 3,
  games: [],
  forwardPicks: [],
  historicalMetrics: [],
  performance: {
    qualifiedCount: 0,
    settledCount: 0,
    wins: 0,
    losses: 0,
    pushes: 0,
    forwardUnits: 0,
    placedCount: 0,
    clvCount: 0,
    positiveClvCount: 0,
    averageClvPoints: null,
  },
} satisfies AppSnapshot;
