import { Link } from "expo-router";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { getQualifiedPicks, lineText, oddsText, pct, signed } from "../data";
import { C } from "../theme";

export default function ModelPicks() {
  const picks = getQualifiedPicks();

  return (
    <View style={s.page}>
      <View style={s.hero}>
        <Text style={s.kicker}>QUALIFYING SIGNALS</Text>
        <Text style={s.title}>Model Picks</Text>
        <Text style={s.sub}>
          Ranked by edge. These are model qualifiers, not guaranteed outcomes.
        </Text>
      </View>

      <FlatList
        data={picks}
        keyExtractor={(x) => `${x.game.id}-${x.pick.market}`}
        contentContainerStyle={s.list}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={s.emptyTitle}>No qualifying picks</Text>
            <Text style={s.emptyText}>
              The model is below its minimum edge on every available market.
            </Text>
          </View>
        }
        renderItem={({ item, index }) => {
          const model = item.pick.selectedProbability ?? 0;
          const needed = item.pick.breakEven ?? 0;
          const edge = item.pick.edge ?? 0;

          return (
            <Link
              href={{ pathname: "/game/[id]", params: { id: item.game.id } }}
              asChild
            >
              <Pressable style={s.card}>
                <View style={s.top}>
                  <View style={s.rankCircle}>
                    <Text style={s.rank}>#{index + 1}</Text>
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={s.match}>
                      {item.game.away} @ {item.game.home}
                    </Text>
                    <Text style={s.market}>
                      {item.pick.market.toUpperCase()}
                    </Text>
                  </View>

                  <View style={s.qualifyPill}>
                    <Text style={s.qualifyText}>QUALIFIED</Text>
                  </View>
                </View>

                <Text style={s.pick}>
                  {lineText(item.pick.market, item.pick.pick, item.pick.line)}{" "}
                  {oddsText(item.pick.odds)}
                </Text>
                <Text style={s.book}>{item.pick.book}</Text>

                <View style={s.visual}>
                  <View style={s.visualRow}>
                    <Text style={s.visualLabel}>Model chance</Text>
                    <Text style={s.visualNumber}>{pct(model)}</Text>
                  </View>
                  <View style={s.track}>
                    <View style={[s.greenFill, { width: `${model * 100}%` }]} />
                  </View>

                  <View style={[s.visualRow, { marginTop: 10 }]}>
                    <Text style={s.visualLabel}>Break-even</Text>
                    <Text style={s.visualNumber}>{pct(needed)}</Text>
                  </View>
                  <View style={s.track}>
                    <View style={[s.goldFill, { width: `${needed * 100}%` }]} />
                  </View>
                </View>

                <View style={s.edgeCallout}>
                  <Text style={s.edgeCalloutLabel}>MODEL EDGE</Text>
                  <Text style={s.edgeCalloutValue}>
                    {signed(edge * 100, 2)}%
                  </Text>
                </View>
              </Pressable>
            </Link>
          );
        }}
      />
    </View>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  hero: { padding: 18, paddingBottom: 6 },
  kicker: { color: C.green, fontSize: 10, fontWeight: "900", letterSpacing: 1.4 },
  title: { color: C.text, fontSize: 31, fontWeight: "900", marginTop: 4 },
  sub: { color: C.muted, marginTop: 5, lineHeight: 19 },
  list: { padding: 16, paddingBottom: 36 },

  card: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: "#285F45",
    borderRadius: 20,
    padding: 17,
  },
  top: { flexDirection: "row", alignItems: "center", gap: 11 },
  rankCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: C.goldSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  rank: { color: C.gold, fontSize: 15, fontWeight: "900" },
  match: { color: C.text, fontSize: 17, fontWeight: "900" },
  market: { color: C.dim, fontSize: 8, fontWeight: "900", marginTop: 2 },
  qualifyPill: {
    backgroundColor: C.greenSoft,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 99,
  },
  qualifyText: { color: C.green, fontSize: 8, fontWeight: "900" },

  pick: { color: C.text, fontSize: 24, fontWeight: "900", marginTop: 16 },
  book: { color: C.muted, fontSize: 11, marginTop: 3 },

  visual: {
    backgroundColor: C.panel2,
    borderRadius: 14,
    padding: 12,
    marginTop: 15,
  },
  visualRow: { flexDirection: "row", justifyContent: "space-between" },
  visualLabel: { color: C.muted, fontSize: 10 },
  visualNumber: { color: C.text, fontSize: 10, fontWeight: "900" },
  track: {
    height: 8,
    backgroundColor: "#252D39",
    borderRadius: 99,
    overflow: "hidden",
    marginTop: 5,
  },
  greenFill: { height: "100%", backgroundColor: C.green },
  goldFill: { height: "100%", backgroundColor: C.gold },

  edgeCallout: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: C.greenSoft,
    borderRadius: 13,
    padding: 12,
    marginTop: 12,
  },
  edgeCalloutLabel: { color: C.green, fontSize: 10, fontWeight: "900" },
  edgeCalloutValue: { color: C.green, fontSize: 17, fontWeight: "900" },

  empty: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 20,
  },
  emptyTitle: { color: C.text, fontSize: 18, fontWeight: "900" },
  emptyText: { color: C.muted, marginTop: 6, lineHeight: 19 },
});
