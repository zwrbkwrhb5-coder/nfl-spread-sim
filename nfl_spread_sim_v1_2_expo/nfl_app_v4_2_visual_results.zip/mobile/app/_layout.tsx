import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";

export default function Layout() {
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: "#090B10" },
          headerTintColor: "#F5F7FA",
          headerTitleStyle: { fontWeight: "900" },
          headerShadowVisible: false,
          contentStyle: { backgroundColor: "#090B10" },
        }}
      >
        <Stack.Screen name="index" options={{ title: "NFL Model" }} />
        <Stack.Screen name="top5" options={{ title: "Model Picks" }} />
        <Stack.Screen name="performance" options={{ title: "Results" }} />
        <Stack.Screen name="game/[id]" options={{ title: "Game Breakdown" }} />
      </Stack>
    </>
  );
}
