import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { APP_DATA, oddsText, shortGameId, signed } from "../data";
import { C } from "../theme";
import type { ForwardPick, HistoricalMetric } from "../types";

function BigStat({
  value,
  label,
  color,
}: {
  value: string;
  label: string;
  color?: string;
}) {
  return (
    <View style={s.bigStat}>
      <Text style={[s.bigStatValue, color ? { color } : undefined]}>{value}</Text>
      <Text style={s.bigStatLabel}>{label}</Text>
    </View>
  );
}

function ClvVisual({ pick }: { pick: ForwardPick }) {
  const clv = pick.clvPointsVsConsensus;
  const good = clv != null && clv > 0;
  const bad = clv != null && clv < 0;

  return (
    <View style={s.clvBox}>
      <View style={s.clvTop}>
        <Text style={s.clvTitle}>Closing-line movement</Text>
        <Text
          style={[
            s.clvResult,
            { color: good ? C.green : bad ? C.red : C.muted },
          ]}
        >
          {clv == null ? "Not captured" : `${signed(clv, 2)} pts CLV`}
        </Text>
      </View>

      {pick.closeConsensusLine != null ? (
        <View style={s.lineMoveRow}>
          <View style={s.lineBubble}>
            <Text style={s.lineBubbleLabel}>ENTRY</Text>
            <Text style={s.lineBubbleValue}>
              {pick.line > 0 ? "+" : ""}{pick.line}
            </Text>
          </View>

          <Text style={s.arrow}>→</Text>

          <View style={s.lineBubble}>
            <Text style={s.lineBubbleLabel}>CLOSE</Text>
            <Text style={s.lineBubbleValue}>
              {pick.closeConsensusLine > 0 ? "+" : ""}
              {pick.closeConsensusLine}
            </Text>
          </View>
        </View>
      ) : (
        <Text style={s.missingClose}>
          No valid pre-kickoff close was captured for this pick.
        </Text>
      )}
    </View>
  );
}

function ForwardCard({ pick }: { pick: ForwardPick }) {
  const result = pick.result?.toLowerCase() ?? null;

  const status =
    result === "win"
      ? { label: "WIN", fg: C.green, bg: C.greenSoft }
      : result === "loss"
      ? { label: "LOSS", fg: "#FF7777", bg: "#35191D" }
      : result === "push"
      ? { label: "PUSH", fg: C.gold, bg: C.goldSoft }
      : { label: "PENDING", fg: C.blue, bg: C.blueSoft };

  return (
    <View style={s.forwardCard}>
      <View style={s.forwardTop}>
        <View>
          <Text style={s.gameName}>{shortGameId(pick.gameId)}</Text>
          <Text style={s.pickLine}>
            {pick.pick} {pick.line > 0 ? "+" : ""}
            {pick.line} {oddsText(pick.odds)}
          </Text>
          <Text style={s.book}>{pick.book}</Text>
        </View>

        <View style={[s.status, { backgroundColor: status.bg }]}>
          <Text style={[s.statusText, { color: status.fg }]}>
            {status.label}
          </Text>
        </View>
      </View>

      <ClvVisual pick={pick} />

      <View style={s.smallStats}>
        <View>
          <Text style={s.smallLabel}>ENTRY EDGE</Text>
          <Text style={s.smallValue}>
            {pick.edge == null ? "—" : `${signed(pick.edge * 100, 2)}%`}
          </Text>
        </View>
        <View>
          <Text style={s.smallLabel}>PLACED</Text>
          <Text style={s.smallValue}>{pick.placed ? "YES" : "NO"}</Text>
        </View>
        <View>
          <Text style={s.smallLabel}>PROFIT</Text>
          <Text style={s.smallValue}>
            {pick.settlementProfitUnits == null
              ? "—"
              : signed(pick.settlementProfitUnits, 2)}
          </Text>
        </View>
      </View>

      {pick.closeNote && (
        <Text style={s.note}>{pick.closeNote.replaceAll("_", " ")}</Text>
      )}
    </View>
  );
}

function HistoricalChart({ m }: { m: HistoricalMetric }) {
  const values = [
    { label: "Sportsbook market", value: m.marketMae, color: C.gold },
    { label: "Our standalone model", value: m.baseModelMae, color: C.red },
    { label: "Market + our model", value: m.stackMae, color: C.green },
  ];
  const max = Math.max(...values.map((x) => x.value), 1);
  const min = Math.min(...values.map((x) => x.value));

  return (
    <View style={s.historyCard}>
      <View style={s.historyTop}>
        <Text style={s.historyTitle}>{m.market.toUpperCase()}</Text>
        <Text style={s.historyGames}>{m.games} games</Text>
      </View>

      <Text style={s.historyHelp}>
        Average prediction error in points. Shorter is better.
      </Text>

      {values.map((x) => (
        <View key={x.label} style={s.histRow}>
          <View style={s.histLabels}>
            <Text style={s.histLabel}>
              {x.label}
              {x.value === min ? "  ✓" : ""}
            </Text>
            <Text style={s.histNumber}>{x.value.toFixed(2)}</Text>
          </View>
          <View style={s.histTrack}>
            <View
              style={[
                s.histFill,
                {
                  backgroundColor: x.color,
                  width: `${Math.max(12, (x.value / max) * 100)}%`,
                },
              ]}
            />
          </View>
        </View>
      ))}

      <View
        style={[
          s.takeaway,
          {
            backgroundColor:
              m.market === "total" ? C.purpleSoft : C.panel2,
          },
        ]}
      >
        <Text
          style={[
            s.takeawayText,
            { color: m.market === "total" ? C.purple : C.muted },
          ]}
        >
          {m.market === "total"
            ? "Totals: the market + model blend showed a small historical improvement. It remains research-only."
            : "Spreads: the sportsbook market has remained stronger than our added model signal."}
        </Text>
      </View>
    </View>
  );
}

export default function Results() {
  const p = APP_DATA.performance;
  const positivePct =
    p.clvCount > 0 ? Math.round((p.positiveClvCount / p.clvCount) * 100) : null;

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <Text style={s.kicker}>FORWARD TEST</Text>
      <Text style={s.title}>Results</Text>
      <Text style={s.sub}>
        The important numbers, shown visually.
      </Text>

      <View style={s.recordHero}>
        <View>
          <Text style={s.recordLabel}>SETTLED RECORD</Text>
          <Text style={s.recordValue}>
            {p.wins}-{p.losses}
            {p.pushes ? `-${p.pushes}` : ""}
          </Text>
        </View>

        <View style={s.unitBlock}>
          <Text style={s.recordLabel}>UNITS</Text>
          <Text
            style={[
              s.units,
              {
                color:
                  p.forwardUnits > 0
                    ? C.green
                    : p.forwardUnits < 0
                    ? "#FF7777"
                    : C.text,
              },
            ]}
          >
            {signed(p.forwardUnits, 2)}
          </Text>
        </View>
      </View>

      <View style={s.statsRow}>
        <BigStat
          value={
            p.averageClvPoints == null ? "—" : signed(p.averageClvPoints, 2)
          }
          label="AVG CLV PTS"
          color={(p.averageClvPoints ?? 0) > 0 ? C.green : C.text}
        />
        <BigStat
          value={positivePct == null ? "—" : `${positivePct}%`}
          label="POSITIVE CLV"
          color={C.blue}
        />
        <BigStat value={`${p.clvCount}`} label="CLV SAMPLES" />
      </View>

      {p.clvCount > 0 && (
        <View style={s.clvProgressCard}>
          <View style={s.progressTop}>
            <Text style={s.progressTitle}>Positive CLV rate</Text>
            <Text style={s.progressValue}>{positivePct}%</Text>
          </View>
          <View style={s.progressTrack}>
            <View
              style={[
                s.progressFill,
                { width: `${positivePct ?? 0}%` },
              ]}
            />
          </View>
          <Text style={s.progressHelp}>
            Positive CLV means the entry price beat the later closing market.
          </Text>
        </View>
      )}

      <Text style={s.section}>PICK-BY-PICK</Text>
      {APP_DATA.forwardPicks.length ? (
        APP_DATA.forwardPicks.map((pick) => (
          <ForwardCard
            key={`${pick.gameId}-${pick.market}-${pick.pick}`}
            pick={pick}
          />
        ))
      ) : (
        <View style={s.empty}>
          <Text style={s.emptyText}>No forward-test picks have been saved yet.</Text>
        </View>
      )}

      <Text style={s.section}>HISTORICAL MODEL VS MARKET</Text>
      {APP_DATA.historicalMetrics.map((m) => (
        <HistoricalChart key={m.market} m={m} />
      ))}

      <View style={s.footerNote}>
        <Text style={s.footerTitle}>What matters most</Text>
        <Text style={s.footerText}>
          We are collecting forward results and CLV before making more model changes.
          A small sample can look great or terrible by chance, so this screen separates
          current evidence from research-only signals.
        </Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 42 },

  kicker: { color: C.blue, fontSize: 10, fontWeight: "900", letterSpacing: 1.5 },
  title: { color: C.text, fontSize: 34, fontWeight: "900", marginTop: 4 },
  sub: { color: C.muted, fontSize: 13, marginTop: 5, marginBottom: 17 },

  recordHero: {
    backgroundColor: "#101925",
    borderWidth: 1,
    borderColor: "#23334B",
    borderRadius: 20,
    padding: 18,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
  },
  recordLabel: { color: C.dim, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  recordValue: { color: C.text, fontSize: 39, fontWeight: "900", marginTop: 3 },
  unitBlock: { alignItems: "flex-end" },
  units: { fontSize: 26, fontWeight: "900", marginTop: 4 },

  statsRow: { flexDirection: "row", gap: 8, marginTop: 9 },
  bigStat: {
    flex: 1,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 15,
    padding: 13,
  },
  bigStatValue: { color: C.text, fontSize: 18, fontWeight: "900" },
  bigStatLabel: { color: C.dim, fontSize: 7, fontWeight: "900", marginTop: 4 },

  clvProgressCard: {
    backgroundColor: C.panel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.line,
    padding: 14,
    marginTop: 9,
  },
  progressTop: { flexDirection: "row", justifyContent: "space-between" },
  progressTitle: { color: C.text, fontWeight: "900", fontSize: 12 },
  progressValue: { color: C.green, fontWeight: "900", fontSize: 12 },
  progressTrack: {
    height: 9,
    backgroundColor: C.panel2,
    borderRadius: 99,
    overflow: "hidden",
    marginTop: 9,
  },
  progressFill: { height: "100%", backgroundColor: C.green },
  progressHelp: { color: C.muted, fontSize: 10, lineHeight: 16, marginTop: 7 },

  section: {
    color: C.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
    marginTop: 23,
    marginBottom: 9,
  },

  forwardCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 16,
    marginBottom: 11,
  },
  forwardTop: { flexDirection: "row", justifyContent: "space-between" },
  gameName: { color: C.muted, fontSize: 10, fontWeight: "800" },
  pickLine: { color: C.text, fontSize: 20, fontWeight: "900", marginTop: 3 },
  book: { color: C.muted, fontSize: 10, marginTop: 3 },

  status: { borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6 },
  statusText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },

  clvBox: {
    backgroundColor: C.panel2,
    borderRadius: 14,
    padding: 12,
    marginTop: 14,
  },
  clvTop: { flexDirection: "row", justifyContent: "space-between", gap: 8 },
  clvTitle: { color: C.muted, fontSize: 10, fontWeight: "800" },
  clvResult: { fontSize: 11, fontWeight: "900" },

  lineMoveRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 13,
    marginTop: 12,
  },
  lineBubble: {
    minWidth: 85,
    backgroundColor: "#202938",
    borderRadius: 12,
    padding: 10,
    alignItems: "center",
  },
  lineBubbleLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  lineBubbleValue: { color: C.text, fontSize: 18, fontWeight: "900", marginTop: 2 },
  arrow: { color: C.gold, fontSize: 22, fontWeight: "900" },
  missingClose: { color: C.muted, fontSize: 10, lineHeight: 16, marginTop: 10 },

  smallStats: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 13,
  },
  smallLabel: { color: C.dim, fontSize: 7, fontWeight: "900" },
  smallValue: { color: C.text, fontSize: 12, fontWeight: "900", marginTop: 3 },
  note: { color: C.gold, fontSize: 10, marginTop: 10 },

  historyCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    padding: 16,
    marginBottom: 11,
  },
  historyTop: { flexDirection: "row", justifyContent: "space-between" },
  historyTitle: { color: C.text, fontSize: 18, fontWeight: "900" },
  historyGames: { color: C.dim, fontSize: 10 },
  historyHelp: { color: C.muted, fontSize: 10, marginTop: 3, marginBottom: 13 },

  histRow: { marginBottom: 12 },
  histLabels: { flexDirection: "row", justifyContent: "space-between" },
  histLabel: { color: C.muted, fontSize: 10 },
  histNumber: { color: C.text, fontSize: 10, fontWeight: "900" },
  histTrack: {
    height: 9,
    backgroundColor: C.panel2,
    borderRadius: 99,
    overflow: "hidden",
    marginTop: 5,
  },
  histFill: { height: "100%", borderRadius: 99 },

  takeaway: { borderRadius: 12, padding: 11, marginTop: 2 },
  takeawayText: { fontSize: 10, lineHeight: 16, fontWeight: "700" },

  footerNote: {
    backgroundColor: C.blueSoft,
    borderRadius: 16,
    padding: 15,
    marginTop: 8,
  },
  footerTitle: { color: C.blue, fontWeight: "900", fontSize: 12 },
  footerText: { color: "#C2D9F4", fontSize: 11, lineHeight: 18, marginTop: 5 },

  empty: {
    backgroundColor: C.panel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.line,
    padding: 16,
  },
  emptyText: { color: C.muted, fontSize: 11 },
});
