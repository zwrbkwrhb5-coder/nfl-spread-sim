import { useLocalSearchParams } from "expo-router";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  getGame,
  lineText,
  oddsText,
  pct,
  projectedScore,
  signed,
} from "../../data";
import { C } from "../../theme";
import type { MarketPick } from "../../types";

function Comparison({
  model,
  needed,
}: {
  model: number | null;
  needed: number | null;
}) {
  const modelWidth = `${Math.max(0, Math.min(100, (model ?? 0) * 100))}%`;
  const neededWidth = `${Math.max(0, Math.min(100, (needed ?? 0) * 100))}%`;

  return (
    <View style={s.comparison}>
      <View style={s.comparisonTop}>
        <Text style={s.comparisonLabel}>Model chance</Text>
        <Text style={s.comparisonValue}>{pct(model)}</Text>
      </View>
      <View style={s.track}>
        <View style={[s.greenFill, { width: modelWidth }]} />
      </View>

      <View style={[s.comparisonTop, { marginTop: 10 }]}>
        <Text style={s.comparisonLabel}>Break-even at this price</Text>
        <Text style={s.comparisonValue}>{pct(needed)}</Text>
      </View>
      <View style={s.track}>
        <View style={[s.goldFill, { width: neededWidth }]} />
      </View>
    </View>
  );
}

function MarketCard({ pick }: { pick: MarketPick }) {
  return (
    <View
      style={[
        s.marketCard,
        pick.qualifies && { borderColor: "#285F45" },
      ]}
    >
      <View style={s.marketTop}>
        <View>
          <Text style={s.eyebrow}>{pick.market.toUpperCase()}</Text>
          <Text style={s.pick}>
            {lineText(pick.market, pick.pick, pick.line)} {oddsText(pick.odds)}
          </Text>
          <Text style={s.book}>Best price: {pick.book}</Text>
        </View>

        <View
          style={[
            s.pill,
            { backgroundColor: pick.qualifies ? C.greenSoft : C.panel2 },
          ]}
        >
          <Text
            style={[
              s.pillText,
              { color: pick.qualifies ? C.green : C.muted },
            ]}
          >
            {pick.qualifies ? "QUALIFIED" : "PASS"}
          </Text>
        </View>
      </View>

      <Comparison
        model={pick.selectedProbability}
        needed={pick.breakEven}
      />

      <View
        style={[
          s.edgeCallout,
          { backgroundColor: pick.qualifies ? C.greenSoft : C.panel2 },
        ]}
      >
        <Text
          style={[
            s.edgeLabel,
            { color: pick.qualifies ? C.green : C.muted },
          ]}
        >
          EDGE
        </Text>
        <Text
          style={[
            s.edgeValue,
            { color: pick.qualifies ? C.green : C.muted },
          ]}
        >
          {signed((pick.edge ?? 0) * 100, 2)}%
        </Text>
      </View>

      <Text style={s.explanation}>
        {pick.qualifies
          ? `This clears the model's minimum edge. The estimated win probability is ${pct(
              pick.selectedProbability
            )}, compared with ${pct(pick.breakEven)} needed to break even.`
          : `This does not clear the model's minimum edge, so it is a pass at the current price.`}
      </Text>

      <Text style={s.advanced}>
        Raw {pct(pick.rawProbability)} • Calibrated{" "}
        {pct(pick.calibratedProbability)}
      </Text>
    </View>
  );
}

export default function GameBreakdown() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const game = getGame(String(id));

  if (!game) {
    return (
      <View style={s.notFound}>
        <Text style={s.notFoundTitle}>Game not found</Text>
      </View>
    );
  }

  const score = projectedScore(game);

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <View style={s.hero}>
        <Text style={s.week}>WEEK {game.week}</Text>
        <Text style={s.matchup}>{game.away} @ {game.home}</Text>
        <Text style={s.qbs}>
          {game.awayQB ?? "QB TBD"} vs {game.homeQB ?? "QB TBD"}
        </Text>

        {score && (
          <View style={s.scoreCard}>
            <Text style={s.scoreLabel}>MODEL PROJECTED SCORE</Text>
            <View style={s.scoreRow}>
              <View style={s.teamBlock}>
                <Text style={s.team}>{game.away}</Text>
                <Text style={s.score}>{score.away.toFixed(1)}</Text>
              </View>

              <Text style={s.scoreDash}>–</Text>

              <View style={s.teamBlock}>
                <Text style={s.team}>{game.home}</Text>
                <Text style={s.score}>{score.home.toFixed(1)}</Text>
              </View>
            </View>
            <Text style={s.projectedTotal}>
              Projected total {game.modelTotal?.toFixed(1) ?? "—"}
            </Text>
          </View>
        )}
      </View>

      <Text style={s.section}>CURRENT MARKETS</Text>
      {game.spread && <MarketCard pick={game.spread} />}
      {game.total && <MarketCard pick={game.total} />}

      {game.shadowTotal && (
        <>
          <Text style={s.section}>RESEARCH ONLY</Text>
          <View style={s.shadowCard}>
            <View style={s.shadowHeader}>
              <Text style={s.shadowTitle}>Totals shadow model</Text>
              <View style={s.researchPill}>
                <Text style={s.researchText}>RESEARCH</Text>
              </View>
            </View>

            <Text style={s.shadowBig}>
              {game.shadowTotal.direction} •{" "}
              {game.shadowTotal.shadowTotal.toFixed(1)}
            </Text>

            <View style={s.shadowNumbers}>
              <View>
                <Text style={s.shadowLabel}>CURRENT MARKET</Text>
                <Text style={s.shadowValue}>
                  {game.shadowTotal.currentConsensusTotal.toFixed(1)}
                </Text>
              </View>
              <Text style={s.shadowArrow}>→</Text>
              <View>
                <Text style={s.shadowLabel}>SHADOW</Text>
                <Text style={s.shadowValue}>
                  {game.shadowTotal.shadowTotal.toFixed(1)}
                </Text>
              </View>
            </View>

            <Text style={s.shadowWarning}>
              Not a production pick. The historical model used closing lines, so
              this live comparison is being tracked separately.
            </Text>
          </View>
        </>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: { padding: 16, paddingBottom: 40 },

  hero: {
    backgroundColor: "#0F1724",
    borderWidth: 1,
    borderColor: "#233149",
    borderRadius: 22,
    padding: 20,
    marginBottom: 22,
  },
  week: { color: C.gold, fontSize: 10, fontWeight: "900", letterSpacing: 1.4 },
  matchup: { color: C.text, fontSize: 31, fontWeight: "900", marginTop: 4 },
  qbs: { color: C.muted, marginTop: 5 },

  scoreCard: {
    backgroundColor: "#151F2E",
    borderRadius: 16,
    padding: 15,
    marginTop: 17,
  },
  scoreLabel: {
    color: C.dim,
    textAlign: "center",
    fontSize: 8,
    fontWeight: "900",
    letterSpacing: 1,
  },
  scoreRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 17,
    marginTop: 9,
  },
  teamBlock: { alignItems: "center", minWidth: 85 },
  team: { color: C.muted, fontSize: 11, fontWeight: "900" },
  score: { color: C.text, fontSize: 31, fontWeight: "900", marginTop: 2 },
  scoreDash: { color: C.dim, fontSize: 24 },
  projectedTotal: { color: C.muted, fontSize: 10, textAlign: "center", marginTop: 7 },

  section: {
    color: C.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
    marginBottom: 9,
  },

  marketCard: {
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 19,
    padding: 17,
    marginBottom: 12,
  },
  marketTop: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  eyebrow: { color: C.gold, fontSize: 9, fontWeight: "900", letterSpacing: 1.1 },
  pick: { color: C.text, fontSize: 21, fontWeight: "900", marginTop: 4 },
  book: { color: C.muted, fontSize: 11, marginTop: 3 },

  pill: { borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6, height: 27 },
  pillText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },

  comparison: {
    backgroundColor: C.panel2,
    borderRadius: 14,
    padding: 12,
    marginTop: 16,
  },
  comparisonTop: { flexDirection: "row", justifyContent: "space-between" },
  comparisonLabel: { color: C.muted, fontSize: 10 },
  comparisonValue: { color: C.text, fontSize: 10, fontWeight: "900" },
  track: {
    height: 8,
    backgroundColor: "#252D39",
    borderRadius: 99,
    overflow: "hidden",
    marginTop: 5,
  },
  greenFill: { height: "100%", backgroundColor: C.green },
  goldFill: { height: "100%", backgroundColor: C.gold },

  edgeCallout: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderRadius: 12,
    padding: 11,
    marginTop: 11,
  },
  edgeLabel: { fontSize: 9, fontWeight: "900" },
  edgeValue: { fontSize: 16, fontWeight: "900" },

  explanation: { color: "#C4CCD8", fontSize: 11, lineHeight: 18, marginTop: 12 },
  advanced: { color: C.dim, fontSize: 9, marginTop: 9 },

  shadowCard: {
    backgroundColor: C.purpleSoft,
    borderWidth: 1,
    borderColor: "#443566",
    borderRadius: 18,
    padding: 16,
  },
  shadowHeader: { flexDirection: "row", justifyContent: "space-between" },
  shadowTitle: { color: C.purple, fontSize: 13, fontWeight: "900" },
  researchPill: {
    backgroundColor: "#342657",
    borderRadius: 99,
    paddingHorizontal: 8,
    paddingVertical: 5,
  },
  researchText: { color: C.purple, fontSize: 8, fontWeight: "900" },
  shadowBig: { color: C.text, fontSize: 22, fontWeight: "900", marginTop: 12 },

  shadowNumbers: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    marginTop: 15,
  },
  shadowLabel: { color: "#A99BCB", fontSize: 8, fontWeight: "900" },
  shadowValue: { color: C.text, fontSize: 20, fontWeight: "900", textAlign: "center" },
  shadowArrow: { color: C.purple, fontSize: 21, fontWeight: "900" },
  shadowWarning: { color: "#D6CBF0", fontSize: 10, lineHeight: 16, marginTop: 13 },

  notFound: {
    flex: 1,
    backgroundColor: C.bg,
    alignItems: "center",
    justifyContent: "center",
  },
  notFoundTitle: { color: C.text, fontSize: 21, fontWeight: "900" },
});
