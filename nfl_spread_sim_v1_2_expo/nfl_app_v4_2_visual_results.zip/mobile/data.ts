import { APP_DATA } from "./generatedData";
import type { GameView, MarketPick } from "./types";

export { APP_DATA };
export type { GameView, MarketPick };

export const pct = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x) ? "—" : `${(x * 100).toFixed(digits)}%`;

export const signed = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x)
    ? "—"
    : `${x >= 0 ? "+" : ""}${x.toFixed(digits)}`;

export const oddsText = (x: number | null | undefined) =>
  x == null || Number.isNaN(x) ? "—" : `${x > 0 ? "+" : ""}${x.toFixed(0)}`;

export const lineText = (
  market: "spread" | "total",
  pick: string,
  line: number
) => {
  if (market === "spread") return `${pick} ${signed(line)}`;
  return `${pick.toUpperCase()} ${line.toFixed(1)}`;
};

export const getGame = (id: string) =>
  APP_DATA.games.find((g) => g.id === id);

export const getQualifiedPicks = () =>
  APP_DATA.games
    .flatMap((g) =>
      [g.spread, g.total]
        .filter((x): x is MarketPick => Boolean(x && x.qualifies))
        .map((pick) => ({ game: g, pick }))
    )
    .sort((a, b) => (b.pick.edge ?? -999) - (a.pick.edge ?? -999));

export const getPassGames = () =>
  APP_DATA.games.filter((g) => !g.qualifies);

export const bestQualifiedPick = (g: GameView) =>
  [g.spread, g.total]
    .filter((x): x is MarketPick => Boolean(x && x.qualifies))
    .sort((a, b) => (b.edge ?? -999) - (a.edge ?? -999))[0] ?? null;

export const bestAvailableAngle = (g: GameView) =>
  [g.spread, g.total]
    .filter((x): x is MarketPick => Boolean(x))
    .sort((a, b) => (b.edge ?? -999) - (a.edge ?? -999))[0] ?? null;

export const modelMarginText = (g: GameView) => {
  if (g.modelMargin == null) return "—";
  const side = g.modelMargin >= 0 ? g.home : g.away;
  return `${side} by ${Math.abs(g.modelMargin).toFixed(1)}`;
};

export const projectedScore = (g: GameView) => {
  if (g.modelMargin == null || g.modelTotal == null) return null;
  return {
    away: (g.modelTotal - g.modelMargin) / 2,
    home: (g.modelTotal + g.modelMargin) / 2,
  };
};

export const shortGameId = (id: string) => {
  const parts = id.split("_");
  if (parts.length >= 4) return `${parts[2]} @ ${parts[3]}`;
  return id.replaceAll("_", " ");
};
