from __future__ import annotations

from pathlib import Path
import gc

import pandas as pd

from src.features import build_team_games


PBP_URL = (
    "https://github.com/nflverse/nflverse-data/releases/download/"
    "pbp/play_by_play_{season}.parquet"
)


def main():
    parts = []

    for season in range(2018, 2026):
        print(f"\nLoading {season} PBP...")

        pbp = pd.read_parquet(PBP_URL.format(season=season))
        print(f"  {season}: {len(pbp):,} plays loaded")

        tg = build_team_games(pbp)
        print(f"  {season}: {len(tg):,} team-game rows built")

        parts.append(tg.copy())

        del pbp
        del tg
        gc.collect()

    out = pd.concat(parts, ignore_index=True)

    out = (
        out
        .drop_duplicates(["game_id", "team"], keep="last")
        .sort_values(["season", "week", "game_id", "team"])
        .reset_index(drop=True)
    )

    path = Path("artifacts/team_games.parquet")
    path.parent.mkdir(parents=True, exist_ok=True)
    out.to_parquet(path, index=False)

    print("\nDONE")
    print(f"Saved: {path}")
    print(f"Rows: {len(out):,}")
    print(f"Seasons: {int(out['season'].min())}-{int(out['season'].max())}")
    print(
        "Duplicate game/team rows:",
        int(out.duplicated(["game_id", "team"]).sum()),
    )


if __name__ == "__main__":
    main()
