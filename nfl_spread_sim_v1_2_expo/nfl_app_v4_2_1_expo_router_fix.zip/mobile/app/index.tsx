import { Link } from "expo-router";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  APP_DATA,
  bestAvailableAngle,
  lineText,
  modelMarginText,
  oddsText,
  pct,
  signed,
} from "../data";
import { C } from "../theme";
import type { GameView } from "../types";

function ChanceBar({
  model,
  needed,
}: {
  model: number | null;
  needed: number | null;
}) {
  const modelWidth = `${Math.max(0, Math.min(100, (model ?? 0) * 100))}%`;
  const neededWidth = `${Math.max(0, Math.min(100, (needed ?? 0) * 100))}%`;

  return (
    <View style={s.chanceBlock}>
      <View style={s.barLabelRow}>
        <Text style={s.barLabel}>Model chance</Text>
        <Text style={s.barNumber}>{pct(model)}</Text>
      </View>
      <View style={s.track}>
        <View style={[s.modelFill, { width: modelWidth }]} />
      </View>

      <View style={[s.barLabelRow, { marginTop: 8 }]}>
        <Text style={s.barLabel}>Break-even</Text>
        <Text style={s.barNumber}>{pct(needed)}</Text>
      </View>
      <View style={s.track}>
        <View style={[s.bookFill, { width: neededWidth }]} />
      </View>
    </View>
  );
}

function GameCard({ game }: { game: GameView }) {
  const angle = bestAvailableAngle(game);
  const qualifies = Boolean(angle?.qualifies);

  return (
    <Link href={{ pathname: "/game/[id]", params: { id: game.id } }} asChild>
      <Pressable
        style={StyleSheet.flatten([
          s.card,
          qualifies ? { borderColor: "#285F45" } : null,
        ])}
      >
        <View style={s.cardTop}>
          <View style={{ flex: 1 }}>
            <Text style={s.matchup}>{game.away} @ {game.home}</Text>
            <Text style={s.projection}>
              Model: {modelMarginText(game)} • Total {game.modelTotal?.toFixed(1) ?? "—"}
            </Text>
          </View>

          <View
            style={[
              s.statusPill,
              { backgroundColor: qualifies ? C.greenSoft : C.panel2 },
            ]}
          >
            <Text
              style={[
                s.statusText,
                { color: qualifies ? C.green : C.muted },
              ]}
            >
              {qualifies ? "QUALIFIED" : "PASS"}
            </Text>
          </View>
        </View>

        {angle ? (
          <>
            <View style={s.pickHero}>
              <View>
                <Text style={s.smallLabel}>
                  {qualifies ? "TOP MODEL PLAY" : "BEST CURRENT ANGLE"}
                </Text>
                <Text style={s.pickText}>
                  {lineText(angle.market, angle.pick, angle.line)}{" "}
                  {oddsText(angle.odds)}
                </Text>
                <Text style={s.book}>at {angle.book}</Text>
              </View>

              <View style={s.edgeBox}>
                <Text style={s.edgeLabel}>EDGE</Text>
                <Text
                  style={[
                    s.edgeValue,
                    { color: qualifies ? C.green : C.muted },
                  ]}
                >
                  {signed((angle.edge ?? 0) * 100, 2)}%
                </Text>
              </View>
            </View>

            <ChanceBar
              model={angle.selectedProbability}
              needed={angle.breakEven}
            />

            {!qualifies && (
              <View style={s.passNote}>
                <Text style={s.passText}>
                  Below the model's minimum edge. No play.
                </Text>
              </View>
            )}
          </>
        ) : (
          <Text style={s.passText}>No current sportsbook quote available.</Text>
        )}
      </Pressable>
    </Link>
  );
}

export default function Home() {
  const p = APP_DATA.performance;

  return (
    <SafeAreaView style={s.page} edges={["bottom"]}>
      <FlatList
        data={APP_DATA.games}
        keyExtractor={(g) => g.id}
        renderItem={({ item }) => <GameCard game={item} />}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        contentContainerStyle={s.list}
        ListHeaderComponent={
          <>
            <View style={s.hero}>
              <Text style={s.week}>2026 • WEEK {APP_DATA.week}</Text>
              <Text style={s.title}>NFL Model</Text>
              <Text style={s.heroText}>
                See the model's best plays first. Green means the edge clears
                our threshold. Gray means pass.
              </Text>

              <View style={s.heroStats}>
                <View style={s.heroStat}>
                  <Text style={[s.heroValue, { color: C.green }]}>
                    {p.qualifiedCount}
                  </Text>
                  <Text style={s.heroLabel}>QUALIFIED</Text>
                </View>
                <View style={s.heroDivider} />
                <View style={s.heroStat}>
                  <Text style={s.heroValue}>{APP_DATA.games.length}</Text>
                  <Text style={s.heroLabel}>GAMES</Text>
                </View>
                <View style={s.heroDivider} />
                <View style={s.heroStat}>
                  <Text style={[s.heroValue, { color: C.blue }]}>
                    {p.averageClvPoints == null
                      ? "—"
                      : signed(p.averageClvPoints, 2)}
                  </Text>
                  <Text style={s.heroLabel}>AVG CLV</Text>
                </View>
              </View>
            </View>

            <View style={s.navRow}>
              <Link href="/top5" asChild>
                <Pressable style={StyleSheet.flatten([s.navCard, s.picksNav])}>
                  <Text style={s.navEyebrow}>TODAY</Text>
                  <Text style={s.navTitle}>Model Picks</Text>
                  <Text style={s.navSub}>Only qualifying plays →</Text>
                </Pressable>
              </Link>

              <Link href="/performance" asChild>
                <Pressable style={StyleSheet.flatten([s.navCard, s.resultsNav])}>
                  <Text style={s.navEyebrow}>TRACKING</Text>
                  <Text style={s.navTitle}>Results</Text>
                  <Text style={s.navSub}>CLV, record & testing →</Text>
                </Pressable>
              </Link>
            </View>

            <View style={s.explainCard}>
              <Text style={s.explainTitle}>Edge made simple</Text>
              <Text style={s.explainText}>
                If the model says 55.0% and the sportsbook price needs 52.4%
                to break even, the edge is +2.6%.
              </Text>
            </View>

            <Text style={s.section}>ALL GAMES</Text>
          </>
        }
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  list: { padding: 16, paddingBottom: 40 },

  hero: {
    backgroundColor: "#0F1724",
    borderWidth: 1,
    borderColor: "#22314A",
    borderRadius: 22,
    padding: 20,
    marginBottom: 12,
  },
  week: { color: C.gold, fontSize: 10, fontWeight: "900", letterSpacing: 1.5 },
  title: { color: C.text, fontSize: 36, fontWeight: "900", marginTop: 4 },
  heroText: { color: "#C7D0DD", fontSize: 13, lineHeight: 20, marginTop: 7 },

  heroStats: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 20,
    backgroundColor: "#131D2B",
    borderRadius: 16,
    paddingVertical: 13,
  },
  heroStat: { flex: 1, alignItems: "center" },
  heroValue: { color: C.text, fontSize: 22, fontWeight: "900" },
  heroLabel: { color: C.dim, fontSize: 8, fontWeight: "900", marginTop: 3 },
  heroDivider: { width: 1, height: 30, backgroundColor: "#29364A" },

  navRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  navCard: { flex: 1, borderRadius: 17, padding: 15 },
  picksNav: { backgroundColor: "#153124", borderWidth: 1, borderColor: "#24563D" },
  resultsNav: { backgroundColor: C.blueSoft, borderWidth: 1, borderColor: "#24486E" },
  navEyebrow: { color: C.muted, fontSize: 8, fontWeight: "900", letterSpacing: 1 },
  navTitle: { color: C.text, fontSize: 17, fontWeight: "900", marginTop: 3 },
  navSub: { color: "#ABB6C5", fontSize: 10, marginTop: 4 },

  explainCard: {
    backgroundColor: C.panel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.line,
    padding: 14,
    marginBottom: 22,
  },
  explainTitle: { color: C.gold, fontWeight: "900", fontSize: 12 },
  explainText: { color: C.muted, fontSize: 11, lineHeight: 17, marginTop: 5 },

  section: {
    color: C.muted,
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.3,
    marginBottom: 9,
  },

  card: {
    backgroundColor: C.panel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.line,
    padding: 17,
  },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  matchup: { color: C.text, fontSize: 21, fontWeight: "900" },
  projection: { color: C.muted, fontSize: 11, marginTop: 4 },

  statusPill: { borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6 },
  statusText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },

  pickHero: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginTop: 17,
  },
  smallLabel: { color: C.dim, fontSize: 8, fontWeight: "900", letterSpacing: 1 },
  pickText: { color: C.text, fontSize: 20, fontWeight: "900", marginTop: 4 },
  book: { color: C.muted, fontSize: 11, marginTop: 2 },

  edgeBox: { alignItems: "flex-end" },
  edgeLabel: { color: C.dim, fontSize: 8, fontWeight: "900" },
  edgeValue: { fontSize: 20, fontWeight: "900", marginTop: 2 },

  chanceBlock: { marginTop: 16 },
  barLabelRow: { flexDirection: "row", justifyContent: "space-between" },
  barLabel: { color: C.muted, fontSize: 10 },
  barNumber: { color: C.text, fontSize: 10, fontWeight: "800" },
  track: {
    height: 7,
    backgroundColor: "#222936",
    borderRadius: 99,
    overflow: "hidden",
    marginTop: 4,
  },
  modelFill: { height: "100%", backgroundColor: C.green, borderRadius: 99 },
  bookFill: { height: "100%", backgroundColor: C.gold, borderRadius: 99 },

  passNote: {
    backgroundColor: C.panel2,
    borderRadius: 11,
    padding: 10,
    marginTop: 13,
  },
  passText: { color: C.muted, fontSize: 11, lineHeight: 17 },
});
