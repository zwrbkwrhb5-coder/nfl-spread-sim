import { APP_DATA } from "./generatedData";
import type { ForwardPick, GameView, MarketPick } from "./types";

export { APP_DATA };
export type { ForwardPick, GameView, MarketPick };

export const pct = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x) ? "—" : `${(x * 100).toFixed(digits)}%`;

export const signed = (x: number | null | undefined, digits = 1) =>
  x == null || Number.isNaN(x)
    ? "—"
    : `${x >= 0 ? "+" : ""}${x.toFixed(digits)}`;

export const oddsText = (x: number | null | undefined) =>
  x == null || Number.isNaN(x) ? "—" : `${x > 0 ? "+" : ""}${x.toFixed(0)}`;

export const lineText = (
  market: "spread" | "total",
  pick: string,
  line: number
) => {
  if (market === "spread") return `${pick} ${signed(line)}`;
  return `${pick.toUpperCase()} ${line.toFixed(1)}`;
};

export const getGame = (id: string) =>
  APP_DATA.games.find((g) => g.id === id);

export const hasStarted = (g: GameView, nowMs = Date.now()) => {
  if (!g.kickoffAt) return false;
  return new Date(g.kickoffAt).getTime() <= nowMs;
};

export const upcomingGames = (nowMs = Date.now()) =>
  APP_DATA.games.filter((g) => !hasStarted(g, nowMs));

export const upcomingQualifiedPicks = (nowMs = Date.now()) =>
  upcomingGames(nowMs)
    .flatMap((g) =>
      [g.spread, g.total]
        .filter((p): p is MarketPick => Boolean(p && p.qualifies))
        .map((pick) => ({ game: g, pick }))
    )
    .sort((a, b) => (b.pick.edge ?? -999) - (a.pick.edge ?? -999));

export const bestQualifiedPick = (g: GameView) =>
  [g.spread, g.total]
    .filter((p): p is MarketPick => Boolean(p && p.qualifies))
    .sort((a, b) => (b.edge ?? -999) - (a.edge ?? -999))[0] ?? null;

export const bestAngle = (g: GameView) =>
  [g.spread, g.total]
    .filter((p): p is MarketPick => Boolean(p))
    .sort((a, b) => (b.edge ?? -999) - (a.edge ?? -999))[0] ?? null;

export const projectedScore = (g: GameView) => {
  if (g.modelMargin == null || g.modelTotal == null) return null;
  return {
    away: (g.modelTotal - g.modelMargin) / 2,
    home: (g.modelTotal + g.modelMargin) / 2,
  };
};

export const kickoffText = (g: GameView) => {
  if (!g.kickoffAt) return "Kickoff TBD";
  const d = new Date(g.kickoffAt);
  return d.toLocaleString("en-US", {
    weekday: "short",
    hour: "numeric",
    minute: "2-digit",
  });
};

const ESPN: Record<string, string> = {
  ARI: "ari", ATL: "atl", BAL: "bal", BUF: "buf", CAR: "car", CHI: "chi",
  CIN: "cin", CLE: "cle", DAL: "dal", DEN: "den", DET: "det", GB: "gb",
  HOU: "hou", IND: "ind", JAX: "jax", KC: "kc", LV: "lv", LAC: "lac",
  LA: "lar", MIA: "mia", MIN: "min", NE: "ne", NO: "no", NYG: "nyg",
  NYJ: "nyj", PHI: "phi", PIT: "pit", SEA: "sea", SF: "sf", TB: "tb",
  TEN: "ten", WAS: "wsh",
};

export const teamLogo = (team: string) => {
  const key = ESPN[team] ?? team.toLowerCase();
  return `https://a.espncdn.com/i/teamlogos/nfl/500/${key}.png`;
};

export const shortGame = (id: string) => {
  const p = id.split("_");
  return p.length >= 4 ? `${p[2]} @ ${p[3]}` : id;
};

export const resultColor = (result: string | null | undefined) => {
  const r = result?.toLowerCase();
  if (r === "win") return "win";
  if (r === "loss") return "loss";
  if (r === "push") return "push";
  return "pending";
};
