import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";

export default function Layout() {
  return (
    <>
      <StatusBar style="light" />
      <Stack screenOptions={{
        headerStyle: { backgroundColor: "#0B0D12" },
        headerTintColor: "#F5F7FA",
        contentStyle: { backgroundColor: "#0B0D12" },
      }}>
        <Stack.Screen name="index" options={{ title: "NFL Spread Simulator" }} />
        <Stack.Screen name="game/[id]" options={{ title: "Game Analysis" }} />
        <Stack.Screen name="top5" options={{ title: "Top 5 Edges" }} />
      </Stack>
    </>
  );
}
