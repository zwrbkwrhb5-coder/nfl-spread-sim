import { FlatList, StyleSheet, Text, View } from "react-native";
import { DEMO_GAMES, pct, signed } from "../data";

export default function Top5() {
 const data=[...DEMO_GAMES].sort((a,b)=>b.probabilityEdge-a.probabilityEdge).slice(0,5);
 return <View style={s.page}>
   <Text style={s.title}>Top 5 Spread Edges</Text>
   <Text style={s.sub}>Ranked by model probability edge</Text>
   <FlatList data={data} keyExtractor={x=>x.id} contentContainerStyle={s.list}
    renderItem={({item,index})=><View style={s.card}>
      <Text style={s.rank}>#{index+1}</Text>
      <View style={{flex:1}}>
        <Text style={s.match}>{item.away} @ {item.home}</Text>
        <Text style={s.pick}>{item.modelSide} {signed(item.bestSpread)} • {item.bestBook} • {item.odds}</Text>
        <Text style={s.meta}>Cover {pct(item.coverProbability)}   Edge {signed(item.probabilityEdge*100)}%   Diff {signed(item.projectedDifferential)}</Text>
      </View>
    </View>}
   />
 </View>
}
const s=StyleSheet.create({
 page:{flex:1,backgroundColor:"#0B0D12",padding:18},
 title:{color:"#F7F8FA",fontSize:28,fontWeight:"900"},
 sub:{color:"#7E8794",marginTop:4},
 list:{gap:12,paddingTop:18},
 card:{flexDirection:"row",gap:14,backgroundColor:"#141821",padding:17,borderRadius:17,borderWidth:1,borderColor:"#252B36"},
 rank:{color:"#D8A441",fontSize:22,fontWeight:"900"},
 match:{color:"#F7F8FA",fontWeight:"900",fontSize:17},
 pick:{color:"#D8DEE6",fontWeight:"700",marginTop:5},
 meta:{color:"#89929F",fontSize:12,marginTop:7}
});
