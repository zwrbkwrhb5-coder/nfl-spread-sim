import { useLocalSearchParams } from "expo-router";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { DEMO_GAMES, pct, signed } from "../../data";

function Metric({label,value}:{label:string,value:string}) {
  return <View style={s.metric}><Text style={s.label}>{label}</Text><Text style={s.metricValue}>{value}</Text></View>;
}

export default function GameDetail() {
  const { id } = useLocalSearchParams<{id:string}>();
  const g = DEMO_GAMES.find(x => x.id === id) ?? DEMO_GAMES[0];
  const openingMatchup = (g.openingDriveHome + g.openingDriveAwayDefenseAllowed) / 2;

  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <Text style={s.kicker}>MODEL PROJECTION</Text>
      <Text style={s.matchup}>{g.away} @ {g.home}</Text>
      <Text style={s.projection}>{g.modelSide} by {Math.abs(g.projectedHomeMargin).toFixed(1)}</Text>

      <View style={s.grid}>
        <Metric label="BEST SPREAD" value={`${g.modelSide} ${signed(g.bestSpread)}`} />
        <Metric label="ODDS" value={`${g.odds > 0 ? "+" : ""}${g.odds}`} />
        <Metric label="COVER %" value={pct(g.coverProbability)} />
        <Metric label="EDGE" value={`${signed(g.probabilityEdge*100)}%`} />
      </View>

      <View style={s.card}>
        <Text style={s.cardTitle}>1,000,000 Simulations</Text>
        <Text style={s.big}>{pct(g.coverProbability)}</Text>
        <Text style={s.muted}>chance {g.modelSide} covers {signed(g.bestSpread)}</Text>
        <View style={s.line}/>
        <Text style={s.row}>Break-even probability  <Text style={s.bold}>{pct(g.breakEven)}</Text></Text>
        <Text style={s.row}>Projected differential  <Text style={s.bold}>{signed(g.projectedDifferential)} pts</Text></Text>
        <Text style={s.row}>Matchup volatility  <Text style={s.bold}>{g.sigma.toFixed(1)}</Text></Text>
        <Text style={s.row}>Best sportsbook  <Text style={s.bold}>{g.bestBook}</Text></Text>
      </View>

      <View style={s.card}>
        <Text style={s.cardTitle}>Opening Drive Intelligence</Text>
        <Text style={s.row}>{g.home} opening-drive score rate  <Text style={s.bold}>{pct(g.openingDriveHome)}</Text></Text>
        <Text style={s.row}>{g.away} defense score allowed  <Text style={s.bold}>{pct(g.openingDriveAwayDefenseAllowed)}</Text></Text>
        <Text style={s.row}>Opening-drive matchup signal  <Text style={s.gold}>{pct(openingMatchup)}</Text></Text>
        <Text style={s.note}>Uses pregame historical tendencies only — never the current game's actual opening drive.</Text>
      </View>

      <View style={s.card}>
        <Text style={s.cardTitle}>Market vs Model</Text>
        <Text style={s.row}>Market spread  <Text style={s.bold}>{signed(g.marketSpread)}</Text></Text>
        <Text style={s.row}>Model margin  <Text style={s.bold}>{signed(g.projectedHomeMargin)}</Text></Text>
        <Text style={s.row}>Model differential  <Text style={s.gold}>{signed(g.projectedDifferential)} pts</Text></Text>
      </View>
    </ScrollView>
  );
}

const s=StyleSheet.create({
 page:{flex:1,backgroundColor:"#0B0D12"},content:{padding:18,gap:14,paddingBottom:40},
 kicker:{color:"#D8A441",fontSize:11,fontWeight:"900",letterSpacing:1.5},
 matchup:{color:"#F6F7F9",fontSize:27,fontWeight:"900"},
 projection:{color:"#D9DEE5",fontSize:18,fontWeight:"700",marginBottom:4},
 grid:{flexDirection:"row",flexWrap:"wrap",gap:10},
 metric:{backgroundColor:"#141821",borderRadius:15,padding:14,width:"48%",borderWidth:1,borderColor:"#252B36"},
 label:{color:"#77808D",fontSize:10,fontWeight:"900"},
 metricValue:{color:"#F6F7F9",fontSize:20,fontWeight:"900",marginTop:5},
 card:{backgroundColor:"#141821",borderRadius:18,padding:18,borderWidth:1,borderColor:"#252B36"},
 cardTitle:{color:"#F6F7F9",fontSize:18,fontWeight:"900",marginBottom:12},
 big:{color:"#F6F7F9",fontSize:42,fontWeight:"900"},
 muted:{color:"#7D8693"},
 line:{height:1,backgroundColor:"#272D38",marginVertical:16},
 row:{color:"#8C95A2",fontSize:15,marginVertical:5},
 bold:{color:"#F3F5F7",fontWeight:"800"},
 gold:{color:"#E0AE4F",fontWeight:"900"},
 note:{color:"#6F7885",fontSize:12,lineHeight:18,marginTop:10}
});
