import { Link } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { DEMO_GAMES, pct, signed } from "../data";

export default function Home() {
  return (
    <SafeAreaView style={s.page} edges={["bottom"]}>
      <View style={s.hero}>
        <Text style={s.kicker}>WEEK 1</Text>
        <Text style={s.title}>Games</Text>
        <Text style={s.sub}>Model projections + 1,000,000 simulation analysis</Text>
      </View>

      <FlatList
        data={DEMO_GAMES}
        keyExtractor={(g) => g.id}
        contentContainerStyle={s.list}
        renderItem={({ item }) => (
          <Link href={{ pathname: "/game/[id]", params: { id: item.id } }} asChild>
            <Pressable style={s.card}>
              <View style={s.row}>
                <View>
                  <Text style={s.matchup}>{item.away} @ {item.home}</Text>
                  <Text style={s.muted}>{item.kickoff}</Text>
                </View>
                <View style={s.edgePill}>
                  <Text style={s.edgeText}>{signed(item.probabilityEdge * 100)}% edge</Text>
                </View>
              </View>
              <View style={s.divider} />
              <View style={s.stats}>
                <View><Text style={s.label}>MODEL</Text><Text style={s.value}>{item.modelSide} {Math.abs(item.projectedHomeMargin).toFixed(1)}</Text></View>
                <View><Text style={s.label}>BEST LINE</Text><Text style={s.value}>{item.modelSide} {signed(item.bestSpread)}</Text></View>
                <View><Text style={s.label}>COVER</Text><Text style={s.value}>{pct(item.coverProbability)}</Text></View>
              </View>
            </Pressable>
          </Link>
        )}
      />

      <Link href="/top5" asChild>
        <Pressable style={s.top5}><Text style={s.top5Text}>View Top 5 Edges →</Text></Pressable>
      </Link>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  page:{flex:1,backgroundColor:"#0B0D12"},
  hero:{padding:20,paddingBottom:8},
  kicker:{color:"#D8A441",fontWeight:"800",letterSpacing:1.5,fontSize:12},
  title:{color:"#F7F8FA",fontSize:34,fontWeight:"900",marginTop:4},
  sub:{color:"#8E96A3",marginTop:4},
  list:{padding:16,gap:12},
  card:{backgroundColor:"#141821",borderRadius:18,padding:18,borderWidth:1,borderColor:"#232A36"},
  row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  matchup:{color:"#F7F8FA",fontWeight:"900",fontSize:20},
  muted:{color:"#7F8896",marginTop:4},
  edgePill:{backgroundColor:"#241E12",paddingHorizontal:10,paddingVertical:7,borderRadius:99},
  edgeText:{color:"#E5B95F",fontWeight:"800"},
  divider:{height:1,backgroundColor:"#252B35",marginVertical:16},
  stats:{flexDirection:"row",justifyContent:"space-between"},
  label:{color:"#717A88",fontSize:10,fontWeight:"800"},
  value:{color:"#F4F6F8",fontWeight:"800",marginTop:4},
  top5:{margin:16,marginTop:0,backgroundColor:"#A5161D",borderRadius:16,padding:17,alignItems:"center"},
  top5Text:{color:"white",fontWeight:"900",fontSize:16},
});
