export type Game = {
  id: string;
  week: number;
  away: string;
  home: string;
  kickoff: string;
  marketSpread: number;
  projectedHomeMargin: number;
  modelSide: string;
  bestSpread: number;
  bestBook: string;
  odds: number;
  coverProbability: number;
  breakEven: number;
  probabilityEdge: number;
  projectedDifferential: number;
  sigma: number;
  openingDriveHome: number;
  openingDriveAwayDefenseAllowed: number;
};

export const DEMO_GAMES: Game[] = [
  {
    id: "demo-buf-mia",
    week: 1,
    away: "MIA",
    home: "BUF",
    kickoff: "Sun 1:00 PM",
    marketSpread: -3.5,
    projectedHomeMargin: 5.8,
    modelSide: "BUF",
    bestSpread: -3.5,
    bestBook: "FanDuel",
    odds: -105,
    coverProbability: 0.574,
    breakEven: 0.512,
    probabilityEdge: 0.062,
    projectedDifferential: 2.3,
    sigma: 13.1,
    openingDriveHome: 0.44,
    openingDriveAwayDefenseAllowed: 0.39,
  },
  {
    id: "demo-phi-dal",
    week: 1,
    away: "DAL",
    home: "PHI",
    kickoff: "Sun 4:25 PM",
    marketSpread: -4,
    projectedHomeMargin: 5.1,
    modelSide: "PHI",
    bestSpread: -4,
    bestBook: "DraftKings",
    odds: -110,
    coverProbability: 0.556,
    breakEven: 0.524,
    probabilityEdge: 0.032,
    projectedDifferential: 1.1,
    sigma: 12.7,
    openingDriveHome: 0.41,
    openingDriveAwayDefenseAllowed: 0.37,
  },
];

export const pct = (x: number) => `${(x * 100).toFixed(1)}%`;
export const signed = (x: number) => `${x >= 0 ? "+" : ""}${x.toFixed(1)}`;
